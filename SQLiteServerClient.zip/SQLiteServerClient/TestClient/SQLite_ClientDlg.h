// SQLite_ClientDlg.h : header file
//

#pragma once

#include "../src/sqliteclient.h"

// CSQLite_ClientDlg dialog
class CSQLite_ClientDlg : public CDialog
{
// Construction
public:
	CSQLite_ClientDlg(CWnd* pParent = NULL);	// standard constructor
	~CSQLite_ClientDlg();

// Dialog Data
	enum { IDD = IDD_SQLITE_CLIENT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();

	CSQLiteClient m_Client;
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
	afx_msg void OnBnClickedButton10();
};
