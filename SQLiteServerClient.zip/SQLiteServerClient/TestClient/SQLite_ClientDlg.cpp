// SQLite_ClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SQLite_Client.h"
#include "SQLite_ClientDlg.h"
#include "../src/sqlitetchar.h"
#include "../sha512/sha512_helper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSQLite_ClientDlg dialog




CSQLite_ClientDlg::CSQLite_ClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSQLite_ClientDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	CSQLiteClient::InitSockets();
}

CSQLite_ClientDlg::~CSQLite_ClientDlg()
{
	CSQLiteClient::UninitSockets();
}

void CSQLite_ClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSQLite_ClientDlg, CDialog)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CSQLite_ClientDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CSQLite_ClientDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CSQLite_ClientDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CSQLite_ClientDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CSQLite_ClientDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CSQLite_ClientDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &CSQLite_ClientDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CSQLite_ClientDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CSQLite_ClientDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &CSQLite_ClientDlg::OnBnClickedButton10)
END_MESSAGE_MAP()


// CSQLite_ClientDlg message handlers

BOOL CSQLite_ClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon


	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CSQLite_ClientDlg::OnBnClickedButton1()
{
	CString strHost;
	GetDlgItemText(IDC_EDIT1, strHost);
	int iPort=GetDlgItemInt(IDC_EDIT2);
	if (m_Client.Connect(strHost, (unsigned short)iPort))
	{
		GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON2)->EnableWindow(TRUE);
	}
}

void CSQLite_ClientDlg::OnBnClickedButton2()
{
	m_Client.Disconnect();
	GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
	GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
}

void CSQLite_ClientDlg::OnBnClickedButton3()
{
	CString strPath;
	GetDlgItemText(IDC_EDIT3, strPath);

	m_Client.sqliteOpen(strPath);
	if (!m_Client.IsConnected()) OnBnClickedButton2();
}

void CSQLite_ClientDlg::OnBnClickedButton4()
{
	m_Client.sqliteClose();
	if (!m_Client.IsConnected()) OnBnClickedButton2();
}

void CSQLite_ClientDlg::OnBnClickedButton5()
{
	int iChanges=m_Client.sqliteChanges();
	if (!m_Client.IsConnected()) OnBnClickedButton2();
	CString str;
	str.Format(_T("Count of rows changed by the last SQL: %d"), iChanges);
	AfxMessageBox(str);
}

void CSQLite_ClientDlg::OnBnClickedButton6()
{
	int iRow=m_Client.sqliteLastInsertRowID();
	if (!m_Client.IsConnected()) OnBnClickedButton2();
	CString str;
	str.Format(_T("RowID of the last row inserted using INSERT: %d"), iRow);
	AfxMessageBox(str);
}

void CSQLite_ClientDlg::OnBnClickedButton7()
{
	CString strSQL;
	GetDlgItemText(IDC_EDIT4, strSQL);

	m_Client.sqliteExec(strSQL);
	if (!m_Client.IsConnected()) OnBnClickedButton2();
}

void CSQLite_ClientDlg::OnBnClickedButton8()
{
	CString strSQL;
	GetDlgItemText(IDC_EDIT4, strSQL);

	CSQLiteTablePtr pTable=m_Client.sqliteQuery2(strSQL);

	if (!m_Client.IsConnected()) OnBnClickedButton2();

	CString strTable;
	if (pTable)
	{
		strTable.Format(_T("sqliteQuery2: rows %d, cols %d\n\n"), pTable().GetRowCount(), pTable().GetColCount());
		for (int i=0; i<pTable().GetColCount(); i++)
		{
			strTable.Append(pTable().GetColName(i));
			if (i==pTable().GetColCount()-1)
				strTable.Append(_T("\n\n"));
			else strTable.Append(_T("\t"));
		}
		if (pTable().GoFirst())
		{
			do 
			{
				for (int i=0; i<pTable().GetColCount(); i++)
				{
					strTable.Append(pTable()[i]);
					if (i==pTable().GetColCount()-1)
						strTable.Append(_T("\n"));
					else strTable.Append(_T("\t"));
				}
			} while(pTable().GoNext());
		}
	}
	AfxMessageBox(strTable);
}

void CSQLite_ClientDlg::OnBnClickedButton9()
{
	CString strUser, strPass;
	GetDlgItemText(IDC_USER, strUser);
	GetDlgItemText(IDC_PASS, strPass);
	
	TCHAR pBuf[SHA512_DIGEST_SIZE*2+1];
	HashStringToHex(strPass, pBuf);

	m_Client.sqliteAuth(strUser, pBuf);

	if (!m_Client.IsConnected()) OnBnClickedButton2();
}

void CSQLite_ClientDlg::OnBnClickedButton10()
{
	TCHAR * strVer=m_Client.sqliteLibVersion();
	CString str;
	str.Format(_T("SQLite Library Version on server: %s"), strVer);
	delete [] strVer;
	if (!m_Client.IsConnected()) OnBnClickedButton2();
	AfxMessageBox(str);
}
