/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "sqlitetable.h"

LPCTSTR CSQLiteTable::GetColName( int iCol )
{
	if (iCol>=0 && iCol<m_iCols)
	{
		return &m_strlstCols[iCol][0];
	}
	return 0;
}

bool CSQLiteTable::GoFirst()
{ 
	if (this==0) return false;
	if (m_lstRows.size()) 
	{
		m_iPos=0; 
		return true;
	}
	return false;
}

bool CSQLiteTable::GoLast()
{ 
	if (m_lstRows.size()) 
	{
		m_iPos=(int)m_lstRows.size()-1; 
		return true;
	}
	return false;
}

bool CSQLiteTable::GoNext()
{ 
	if (m_iPos+1<(int)m_lstRows.size()) 
	{
		m_iPos++; 
		return true;
	}
	return false;
}

bool CSQLiteTable::GoPrev()
{
	if (m_iPos>0)
	{
		m_iPos--;
		return true;
	}
	return false;
}

bool CSQLiteTable::GoRow(unsigned int iRow)
{
	if (this==0) return false;
	if (iRow<m_lstRows.size())
	{
		m_iPos=iRow;
		return true;
	}
	return false;
}

LPCTSTR CSQLiteTable::GetValue(LPCTSTR lpColName)
{
	if (!lpColName) return 0;
	if (m_iPos<0) return 0;
	for (int i=0; i<m_iCols; i++)
	{
		if (!_tcsicmp(&m_strlstCols[i][0],lpColName))
		{
			return &m_lstRows[m_iPos][i][0];
		}
	}
	return 0;
}

LPCTSTR CSQLiteTable::GetValue(int iColIndex)
{
	if (iColIndex<0 || iColIndex>=m_iCols) return 0;
	if (m_iPos<0) return 0;
	return &m_lstRows[m_iPos][iColIndex][0];
}

LPCTSTR CSQLiteTable::operator [] (LPCTSTR lpColName)
{
	if (!lpColName) return 0;
	if (m_iPos<0) return 0;
	for (int i=0; i<m_iCols; i++)
	{
		if (!_tcsicmp(&m_strlstCols[i][0],lpColName))
		{
			return &m_lstRows[m_iPos][i][0];
		}
	}
	return 0;
}

LPCTSTR CSQLiteTable::operator [] (int iColIndex)
{
	if (iColIndex<0 || iColIndex>=m_iCols) return 0;
	if (m_iPos<0) return 0;
	return &m_lstRows[m_iPos][iColIndex][0];
}

void CSQLiteTable::JoinTable(CSQLiteTable & tblJoin)
{
	if (m_iCols==0) {
		*this=tblJoin;
		return;
	}
	if (m_iCols!=tblJoin.m_iCols) return;

	if (tblJoin.m_iRows>0)
	{
		m_iRows+=tblJoin.m_iRows;

		for (std::vector<row>::iterator it=tblJoin.m_lstRows.begin();
			it!=tblJoin.m_lstRows.end(); it++)
		{
			m_lstRows.push_back(*it);
		}
	}
}

CSQLiteTablePtr::CSQLiteTablePtr( )
{ 
	m_pTable=0; 
}

CSQLiteTablePtr::CSQLiteTablePtr( CSQLiteTable * pTable )
{
	m_pTable = pTable; 
}

CSQLiteTablePtr::CSQLiteTablePtr( const CSQLiteTablePtr& cTablePtr )
{
	m_pTable=cTablePtr.m_pTable;

	// Copy constructors and operators, 
	// for a good reason, must take const reference,
	// but here, for a good reason, we must modify the referenced object,
	// so it won't get freed by the original.
	// I'm using a simple technique to bypass the const declaration
	((CSQLiteTablePtr *)&cTablePtr)->m_pTable=0;
}

CSQLiteTablePtr::~CSQLiteTablePtr()
{ 
	if (m_pTable) delete m_pTable; 
}

void CSQLiteTablePtr::operator =( const CSQLiteTablePtr& cTablePtr )
{
	if (m_pTable) delete m_pTable;
	m_pTable=cTablePtr.m_pTable;

	// Copy constructors and operators, 
	// for a good reason, must take const reference,
	// but here, for a good reason, we must modify the referenced object,
	// so it won't get freed by the original.
	// I'm using a simple technique to bypass the const declaration
	((CSQLiteTablePtr *)&cTablePtr)->m_pTable=0;
}

CSQLiteTable * CSQLiteTablePtr::Detach()
{
	CSQLiteTable * pTable=m_pTable;
	m_pTable=0;
	return pTable;
}

void CSQLiteTablePtr::Attach( CSQLiteTable * pTable )
{
	if (m_pTable) delete m_pTable;
	m_pTable=pTable;
}

void CSQLiteTablePtr::Destroy()
{
	if (m_pTable) delete m_pTable;
	m_pTable=0;
}