/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "requesthandler.h"
#include "verbose.h"
#include "sqliteserver.h"

CRequestHandler::CRequestHandler(CSQLiteServer * pParentServer)
{
	m_pDB = 0;
	m_pParentServer=pParentServer;
	m_Rights=sqliteNoRights;
}

CRequestHandler::~CRequestHandler()
{
	if (m_pDB) 
	{
		sqlite3_close(m_pDB);
		m_pDB=0;
	}
}

int CRequestHandler::HandleRequest(SOCKET sock, CSocketStack * pStack)
{
	int iRes = pStack->RecvMessage(sock);
	if (iRes == SOCKET_STACK_OK)
	{
		unsigned char Method = pStack->ReadByte();
		try
		{
			switch (SQLiteMethodName(Method))
			{
			case METHOD_None:
				{
					pStack->Reset();
					pStack->WriteInt(SOCKET_STACK_OK);
				}
				break;
			case METHOD_auth:
				{
					STACK_Str in_user = pStack->ReadStr();
					STACK_Str in_pass = pStack->ReadStr();

					if (m_pParentServer)
					{
						if (m_pParentServer->m_pAuthLayer)
						{
							m_Rights=m_pParentServer->m_pAuthLayer->IsAuthorized(in_user, in_pass);
						}
					}

					// Reset stack
					pStack->Reset();

					if (m_Rights==sqliteNoRights)
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					else pStack->WriteInt(SOCKET_STACK_OK);
				} // end of case METHOD_auth:
				break;
			case METHOD_sqlite_open:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Read input parameters
						STACK_Str in_filename = pStack->ReadStr();
						STACK_Int in_mode = pStack->ReadInt();

						// Defining output parameters
						STACK_Int out_errcode=0;
						STACK_Str out_errmsg=0;

						// Reduce rights according to user authorization
						if ((m_Rights&sqliteRightWrite)==0)
						{
							if ((in_mode&SQLITE_OPEN_READWRITE)!=0)
								in_mode-=SQLITE_OPEN_READWRITE;
							if ((m_Rights&sqliteRightRead)!=0)
								in_mode|=SQLITE_OPEN_READONLY;
						}
						if ((m_Rights&sqliteRightCreateDB)==0)
						{
							in_mode-=in_mode&SQLITE_OPEN_CREATE;
						}

						// Call method
						int iRes = svc_sqlite_open(in_filename, in_mode, &out_errcode, &out_errmsg);

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);

						// Write back output parameters
						if (iRes == SOCKET_STACK_OK)
						{
							pStack->WriteInt(out_errcode);
							pStack->WriteStr(out_errmsg);
						} 	 
					}
				} // end of case METHOD_sqlite_open:
				break;
			case METHOD_sqlite_close:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Call method
						int iRes = svc_sqlite_close();

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);
					}
				} // end of case METHOD_sqlite_close:
				break;
			case METHOD_sqlite_changes:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Defining output parameters
						STACK_Int out_count;

						// Call method
						int iRes = svc_sqlite_changes(&out_count);

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);

						// Write back output parameters
						if (iRes == SOCKET_STACK_OK) pStack->WriteInt(out_count);
					}
				} // end of case METHOD_sqlite_changes:
				break;
			case METHOD_sqlite_last_insert_rowid:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Defining output parameters
						STACK_Int out_rowid;

						// Call method
						int iRes = svc_sqlite_last_insert_rowid(&out_rowid);

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);

						// Write back output parameters
						if (iRes == SOCKET_STACK_OK) pStack->WriteInt(out_rowid);
					}
				} // end of case METHOD_sqlite_last_insert_rowid:
				break;
			case METHOD_sqlite_interrupt:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Call method
						int iRes = svc_sqlite_interrupt();

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);
					}
				} // end of case METHOD_sqlite_interrupt:
				break;
			case METHOD_sqlite_libversion:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Defining output parameters
						STACK_Str out_version=0;

						// Call method
						int iRes = svc_sqlite_libversion(&out_version);

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);

						// Write back output parameters
						if (iRes == SOCKET_STACK_OK) pStack->WriteStr(out_version);
					}
				} // end of case METHOD_sqlite_libversion:
				break;
			case METHOD_sqlite_exec:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Read input parameters
						STACK_Str in_sql = pStack->ReadStr();

						// Defining output parameters
						STACK_Int out_errcode=0;
						STACK_Str out_errmsg=0;

						// Call method
						int iRes = svc_sqlite_exec(in_sql, &out_errcode, &out_errmsg);

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);

						// Write back output parameters
						if (iRes == SOCKET_STACK_OK)
						{
							pStack->WriteInt(out_errcode);
							pStack->WriteStr(out_errmsg);
							sqlite3_free(out_errmsg);
						} 	 
					}
				} // end of case METHOD_sqlite_exec:
				break;
			case METHOD_sqlite_get_table:
				{
					if (m_Rights==sqliteNoRights)
					{
						pStack->Reset();
						pStack->WriteInt(SOCKET_STACK_NO_RIGHTS);
					} else {
						// Read input parameters
						STACK_Str in_sql = pStack->ReadStr();

						// Defining output parameters
						STACK_Int out_errcode=0;
						STACK_Str out_errmsg=0;
						STACK_Int out_rows=0;
						STACK_Int out_cols=0;
						STACK_StrArray out_results={0,0};

						// Call method
						int iRes = svc_sqlite_get_table(in_sql, 
							&out_errcode, &out_errmsg, 
							&out_rows, &out_cols, &out_results);

						// Reset stack
						pStack->Reset();

						// Write server result
						pStack->WriteInt(iRes);

						// Write back output parameters
						if (iRes == SOCKET_STACK_OK)
						{
							pStack->WriteInt(out_errcode);
							pStack->WriteStr(out_errmsg);
							sqlite3_free(out_errmsg);
							pStack->WriteInt(out_rows);
							pStack->WriteInt(out_cols);
							pStack->WriteStrArray(out_results);
						} 	 

						if (out_results.pItems)	sqlite3_free_table(out_results.pItems);
					}
				} // end of case METHOD_sqlite_get_table:
				break;
			default:
				return SOCKET_STACK_WRONG_FORMAT_OR_TOO_BIG;
			} // end of case
		} // end of try
		catch(...)
		{
			// Something went wrong
			pStack->Reset();
			pStack->WriteInt(SOCKET_STACK_SERVER_STUB_ERROR);
		}
	}
	else
	{
		// Message broken. Try to send error back.
		return iRes;
	}

	// Send and return
	return pStack->SendMessage(sock);
}

int CRequestHandler::svc_sqlite_open(STACK_Str in_filename, STACK_Int in_mode,
									 STACK_Int *out_errcode, STACK_Str *out_errmsg)
{
	try
	{
		sqlite3* db=0;
		*out_errcode=sqlite3_open_v2(in_filename,&db,in_mode,0);
		if (*out_errcode!=SQLITE_OK)
		{
			if (db) 
			{
				*out_errmsg=(STACK_Str)sqlite3_errmsg(db);
				sqlite3_close(db);
			}
		} else {
			VERBOSE_TRACE(_T("CRequestHandler::svc_sqlite_open(): Success.\n"));
			if (m_pDB) sqlite3_close(m_pDB);
			m_pDB=db;
		}
	}
	catch(...)
	{
		return SOCKET_STACK_SERVER_STUB_ERROR;
	}
	return SOCKET_STACK_OK;
}	

int CRequestHandler::svc_sqlite_close()
{
	if (m_pDB)
	{
		sqlite3_close(m_pDB);
		m_pDB=0;
		VERBOSE_TRACE(_T("CRequestHandler::svc_sqlite_close(): Success.\n"));
	} else {
		VERBOSE_TRACE(_T("CRequestHandler::svc_sqlite_close(): Wasn't open!\n"));
	}
	return SOCKET_STACK_OK;
}	

int CRequestHandler::svc_sqlite_changes(STACK_Int *out_count )
{
	if (m_pDB)
	{
		(*out_count) = sqlite3_changes(m_pDB);
		return SOCKET_STACK_OK;
	}
	else
		return SOCKET_STACK_NOT_OPEN;
}	

int CRequestHandler::svc_sqlite_last_insert_rowid(STACK_Int *out_rowid )
{
	if (m_pDB)
	{
		(*out_rowid) = (STACK_Int)sqlite3_last_insert_rowid(m_pDB);
		return SOCKET_STACK_OK;
	}
	else
		return SOCKET_STACK_NOT_OPEN;
}	


int CRequestHandler::svc_sqlite_interrupt()
{
	if (m_pDB)
	{
		sqlite3_interrupt(m_pDB);
		return SOCKET_STACK_OK;
	}
	else
		return SOCKET_STACK_NOT_OPEN;
}	

int CRequestHandler::svc_sqlite_libversion(STACK_Str *out_version )
{
	(*out_version) = (char*)sqlite3_libversion();
	return SOCKET_STACK_OK;
}	

int CRequestHandler::svc_sqlite_exec(STACK_Str in_sql, 
										STACK_Int *out_errcode, STACK_Str *out_errmsg)
{
	if (m_pDB)
	{
		try
		{
			*out_errcode=sqlite3_exec(m_pDB, in_sql, 0, 0, out_errmsg);
		}
		catch(...)
		{
			return SOCKET_STACK_SERVER_STUB_ERROR;
		}
		return SOCKET_STACK_OK;
	}
	else
		return SOCKET_STACK_NOT_OPEN;
}

int CRequestHandler::svc_sqlite_get_table(STACK_Str in_sql, 
					  STACK_Int *out_errcode, STACK_Str *out_errmsg,
					  STACK_Int *out_rows, STACK_Int *out_cols, STACK_StrArray *out_results)
{
	if (m_pDB)
	{
		try
		{
			*out_errcode=sqlite3_get_table(m_pDB, in_sql, &out_results->pItems,
				out_rows, out_cols, out_errmsg);

			out_results->iLen=*out_rows**out_cols+*out_cols;
		}
		catch(...)
		{
			return SOCKET_STACK_SERVER_STUB_ERROR;
		}
		return SOCKET_STACK_OK;
	}
	else
		return SOCKET_STACK_NOT_OPEN;
}
