/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "socket.h"
#include "verbose.h"
#include "csconv.h"
#include <Wspiapi.h>

int socket_init()
{
	int res;
	struct WSAData wsaData;
	if ((res = WSAStartup(MAKEWORD(1, 1), &wsaData)) != 0)
	{
		VERBOSE_TRACE(_T("WSAStartup failed.\n"));
	}
	return res;
}

int socket_uninit()
{
	int res = WSACleanup();
	return res;
}

SOCKET socket_accept(SOCKET sockfd, struct sockaddr * sock_addr, int * sock_addr_length)
{
	return accept(sockfd, (struct sockaddr *)sock_addr, sock_addr_length);
}

SOCKET socket_server(unsigned short port)
{
	struct sockaddr_in addr;

	addr.sin_family = PF_INET;
	addr.sin_port = htons(port);
	memset(addr.sin_zero, 0, 8);

	SOCKET sockfd = socket(PF_INET, SOCK_STREAM, IPPROTO_IP);

	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int val = 1;

	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&val, sizeof(val)) == SOCKET_ERROR)
	{
		VERBOSE_TRACE(_T("socket_server(%d): setsockopt error.\n"), port);
		return INVALID_SOCKET;
	}
	if (bind(sockfd, (struct sockaddr *)&addr, sizeof(struct sockaddr)) == SOCKET_ERROR)
	{
		VERBOSE_TRACE(_T("socket_server(%d): bind error\n"), port);
		return INVALID_SOCKET;
	}
	if (listen(sockfd, SOMAXCONN) == SOCKET_ERROR)
	{
		VERBOSE_TRACE(_T("socket_server(%d): listen error %d\n"), port, GetLastError());
		return INVALID_SOCKET;
	}
	return sockfd;
}

SOCKET socket_client(char* port, char* host, struct addrinfo **aiList)
{
	static struct addrinfo aiHints={0,0,0,0,0,0,0,0};

	aiHints.ai_family = AF_INET;
	aiHints.ai_socktype = SOCK_STREAM;
	aiHints.ai_protocol = IPPROTO_TCP;

	if (getaddrinfo(host, port, &aiHints, aiList) != 0) return INVALID_SOCKET;

	return socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
}

SOCKET socket_client(TCHAR* port, TCHAR* host, struct addrinfo **aiList)
{
	char * port_mb=wchartochar(port);
	char * host_mb=wchartochar(host);
	SOCKET sockfd=socket_client(port_mb, host_mb, aiList);
	if (port_mb) delete [] port_mb;
	if (host_mb) delete [] host_mb;
	return sockfd;
}

void socket_free_addrinfo(struct addrinfo *aiList)
{
	freeaddrinfo(aiList);
}

void socket_close(SOCKET sock)
{
	closesocket(sock);
}
