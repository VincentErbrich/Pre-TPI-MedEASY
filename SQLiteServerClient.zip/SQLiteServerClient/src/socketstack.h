/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#pragma once

#include "socketstream.h"

typedef unsigned char STACK_Byte;

typedef char* STACK_Str;

typedef struct
{
	int iLen;
	STACK_Str* pItems;
} STACK_StrArray;

typedef int STACK_Int;

#define SOCKET_STACK_OK							0
#define SOCKET_STACK_SEND_ERROR					1
#define SOCKET_STACK_RECV_HEADER_ERROR			2
#define SOCKET_STACK_RECV_BODY_ERROR			3
#define SOCKET_STACK_ACCEPT_ERROR				4
#define SOCKET_STACK_CONNECT_ERROR				5
#define SOCKET_STACK_WRONG_FORMAT_OR_TOO_BIG	6
#define SOCKET_STACK_SERVER_STUB_ERROR			7
#define SOCKET_STACK_NOT_OPEN					8
#define SOCKET_STACK_NO_RIGHTS					9
#define SOCKET_STACK_USER_ERROR_BASE			1000

#define SOCKET_STACK_MAX_SIZE					0x00100000 //1024*1024=1MB
#define SOCKET_STACK_HEADER_SIZE				4

class CSocketStack : public CSocketStream
{
private:
	int m_iToGet;
protected:
	CSocketStream* m_pStreamHeader;
public:
	CSocketStack();
	~CSocketStack();

	static const TCHAR* GetErrorMessageStr(int iErr);

	void InsertHeader();
	void ReadHeader();

	int Invoke(SOCKET sock);

	int SendMessageBuffer(SOCKET sock);
	int SendMessage(SOCKET sock);
	int RecvMessage(SOCKET sock);

	STACK_StrArray ReadStrArray();
	void WriteStrArray(const STACK_StrArray& strArray);
};
