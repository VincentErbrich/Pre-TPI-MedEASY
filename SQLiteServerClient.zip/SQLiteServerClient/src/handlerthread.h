/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#pragma once

#include "threadbase.h"
#include "clientconnection.h"
#include "servermainthread.h"
#include "authinterface.h"

class CHandlerThread : public CThreadBase
{
public:
	CHandlerThread();
	CHandlerThread(CClientConnection * pConnection, CSQLiteServer * pParentServer);

	void ExecuteThread();

	CClientConnection * m_pConnection;
	CSQLiteServer * m_pParentServer;
};