/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "sqliteclient.h"
#include "csconv.h"
#include "socket.h"
#include "sqlitemethodname.h"
#include "sqlitetchar.h"
#include "verbose.h"

CSQLiteClient::CSQLiteClient()
{
	m_sPort=SQLITE_SERVER_DEFAULT_PORT;
	m_bConnected=false;
	m_strHost=0;
	m_sockfd=INVALID_SOCKET;
	m_pAddrInfo=0;
	m_iLastError=SQLITE_OK;
	m_strLastError=0;
}

CSQLiteClient::~CSQLiteClient()
{
	if (m_strHost) delete [] m_strHost;
	Disconnect();
	if (m_pAddrInfo) socket_free_addrinfo(m_pAddrInfo);
	ClearLastError();
}

int CSQLiteClient::InitSockets()
{
	return socket_init();
}

int CSQLiteClient::UninitSockets()
{
	return socket_uninit();
}

bool CSQLiteClient::Connect(const TCHAR * strHost, unsigned short sPort)
{
	if (m_bConnected) return false;

	SetPort(sPort);
	SetHost(strHost);

	return Connect();
}

bool CSQLiteClient::Connect()
{
	if (m_bConnected) return false;

	if (m_pAddrInfo) 
	{
		socket_free_addrinfo(m_pAddrInfo);
		m_pAddrInfo=0;
	}

	TCHAR * strPort = new TCHAR[16];
	_itot_s((int)m_sPort, strPort, 16, 10);
	m_sockfd = socket_client(strPort,m_strHost,&m_pAddrInfo);
	delete [] strPort;
	if (m_sockfd == INVALID_SOCKET)
	{
		VERBOSE_TRACE(_T("CSQLiteClient::Connect(): socket_client failed\n"));
		return false;
	}

	struct addrinfo * pAddrInfo=m_pAddrInfo;
	while (pAddrInfo && pAddrInfo->ai_addr)
	{
		if (connect(m_sockfd, pAddrInfo->ai_addr, (int)pAddrInfo->ai_addrlen)==0)
			break;
		else
			pAddrInfo=pAddrInfo->ai_next;
	}

	if (pAddrInfo==0) {
		socket_close(m_sockfd);
		m_sockfd=INVALID_SOCKET;
		if (m_pAddrInfo) 
		{
			socket_free_addrinfo(m_pAddrInfo);
			m_pAddrInfo=0;
		}
		return false;
	}

	VERBOSE_TRACE(_T("CSQLiteClient::Connect(): Success! connected to %d.%d.%d.%d on port %d\n"),
		(BYTE)pAddrInfo->ai_addr->sa_data[2],
		(BYTE)pAddrInfo->ai_addr->sa_data[3],
		(BYTE)pAddrInfo->ai_addr->sa_data[4],
		(BYTE)pAddrInfo->ai_addr->sa_data[5],
		m_sPort);

	ClearLastError();

	m_bConnected=true;
	return true;
}

void CSQLiteClient::Disconnect()
{
	if (m_sockfd!=INVALID_SOCKET)
	{
		socket_close(m_sockfd);
		m_sockfd=INVALID_SOCKET;
		VERBOSE_TRACE(_T("CSQLiteClient::Disconnect(): Disconnected.\n"));
	}
	if (m_pAddrInfo) 
	{
		socket_free_addrinfo(m_pAddrInfo);
		m_pAddrInfo=0;
	}
	m_bConnected=false;
}

bool CSQLiteClient::IsConnected()
{
	return (m_bConnected && m_sockfd!=INVALID_SOCKET);
}

bool CSQLiteClient::SetPort(unsigned short sPort)
{
	if (m_bConnected) return false;
	else {
		m_sPort=sPort;
		return true;
	}
}

unsigned short CSQLiteClient::GetPort()
{
	return m_sPort;
}

void CSQLiteClient::SetHost(const TCHAR * strHost)
{
	if (m_strHost) delete [] m_strHost;
	if (strHost==0) m_strHost=0;
	else {
		int iLen=(int)_tcslen(strHost);
		m_strHost=new TCHAR[iLen+1];
		_tcsncpy_s(m_strHost, iLen+1, strHost, iLen);
	}
}

TCHAR * CSQLiteClient::GetHost()
{
	return m_strHost;
}

int CSQLiteClient::GetLastError()
{
	return m_iLastError;
}

TCHAR * CSQLiteClient::GetLastErrorString()
{
	return m_strLastError;
}

void CSQLiteClient::ClearLastError()
{
	if (m_strLastError) 
	{
		delete [] m_strLastError;
		m_strLastError=0;
	}
	m_iLastError=SQLITE_OK;
}

bool CSQLiteClient::sqliteAuth(const TCHAR * strUser, const TCHAR * strPass)
{
	int iRes=svc_auth(UTF8MBSTR(strUser), UTF8MBSTR(strPass));

	if (iRes==SOCKET_STACK_OK) return true;
	else {
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteAuth(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
		return false;
	}
}

bool CSQLiteClient::sqliteOpen(const TCHAR * strFileName, int in_mode)
{
	int iErr=0;
	char * errmsg=0;
	int iRes=svc_sqlite_open(UTF8MBSTR(strFileName), SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, &iErr, &errmsg);

	if (iRes!=SOCKET_STACK_OK)
	{
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteOpen(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
	}
	if (iErr)
	{
		m_iLastError=iErr;
		if (m_strLastError) 
		{
			delete [] m_strLastError;
			m_strLastError=0;
		}
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteOpen(): SQLite error %d\n"), iErr);
	}
	if (errmsg) 
	{
		int iLen=(int)strlen(errmsg);
		UTF8MBSTR::ConvertUTF8ToString(errmsg, iLen+1, m_strLastError);
		free(errmsg);
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteOpen(): SQLite error %s\n"), m_strLastError);
	}

	if (iErr==SQLITE_OK && iRes==SOCKET_STACK_OK) return true;
	else return false;
}

void CSQLiteClient::sqliteClose()
{
	int iRes=svc_sqlite_close();
	if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
	{
		Disconnect();
	}
}

int CSQLiteClient::sqliteChanges()
{
	int iChanges=0;
	int iRes=svc_sqlite_changes(&iChanges);

	if (iRes==SOCKET_STACK_OK)
	{
		return iChanges;
	} else {
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteChanges(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
		return -1;
	}
}

int CSQLiteClient::sqliteLastInsertRowID()
{
	int iRow=0;
	int iRes=svc_sqlite_last_insert_rowid(&iRow);

	if (iRes==SOCKET_STACK_OK)
	{
		return iRow;
	} else {
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteLastInsertRowID(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
		return -1;
	}
}

bool CSQLiteClient::sqliteInterrupt()
{
	int iRes=svc_sqlite_interrupt();

	if (iRes==SOCKET_STACK_OK) return true;
	else {
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteInterrupt(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
		return false;
	}
}

TCHAR * CSQLiteClient::sqliteLibVersion()
{
	char * libver=0;
	int iRes=svc_sqlite_libversion(&libver);

	if (iRes!=SOCKET_STACK_OK)
	{
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteLibVersion(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
	}
	if (libver) 
	{
		TCHAR * pStrVer=0;
		int iLen=(int)strlen(libver);
		UTF8MBSTR::ConvertUTF8ToString(libver, iLen+1, pStrVer);
		free(libver);
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteLibVersion(): %s\n"), pStrVer);
		return pStrVer;
	} else {
		return 0;
	}
}

bool CSQLiteClient::sqliteExec(const TCHAR * strSQL)
{
	int iErr=0;
	char * errmsg=0;
	int iRes=svc_sqlite_exec(UTF8MBSTR(strSQL), &iErr, &errmsg);

	if (iRes!=SOCKET_STACK_OK)
	{
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteExec(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
	}
	if (iErr)
	{
		m_iLastError=iErr;
		if (m_strLastError) 
		{
			delete [] m_strLastError;
			m_strLastError=0;
		}
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteExec(): SQLite error %d\n"), iErr);
	}
	if (errmsg) 
	{
		int iLen=(int)strlen(errmsg);
		UTF8MBSTR::ConvertUTF8ToString(errmsg, iLen+1, m_strLastError);
		free(errmsg);
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteExec(): SQLite error %s\n"), m_strLastError);
	}

	if (iErr==SQLITE_OK && iRes==SOCKET_STACK_OK) return true;
	else return false;
}

CSQLiteTable CSQLiteClient::sqliteQuery(const TCHAR * strSQL)
{
#ifdef _DEBUG
	int iTick=GetTickCount();
#endif
	int iErr=0,iRows=0,iCols=0;
	char * errmsg=0;
	STACK_StrArray results={0,0};
	int iRes=svc_sqlite_get_table(UTF8MBSTR(strSQL), &iErr, &errmsg,
		&iRows, &iCols, &results);

	if (iRes!=SOCKET_STACK_OK)
	{
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
	}
	if (iErr)
	{
		m_iLastError=iErr;
		if (m_strLastError) 
		{
			delete [] m_strLastError;
			m_strLastError=0;
		}
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery(): SQLite error %d\n"), iErr);
	}
	if (errmsg) 
	{
		int iLen=(int)strlen(errmsg);
		UTF8MBSTR::ConvertUTF8ToString(errmsg, iLen+1, m_strLastError);
		free(errmsg);
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery(): SQLite error %s\n"), m_strLastError);
	}

	CSQLiteTable retTable;

	if (results.pItems)
	{
		if (iRows>0) retTable.m_iPos=0; // Put retTable's cursor on first row
		retTable.m_iCols=iCols;
		retTable.m_iRows=iRows;

		// allocate the memory for the header
		retTable.m_strlstCols.reserve(iCols);

		int iPos=0;

		for (; iPos<iCols; iPos++)
		{
			// Add a string element
			retTable.m_strlstCols.push_back(stdvstring());

			// Convert the UTF8 to TCHAR string
			if (results.pItems[iPos])
				ConvertUTF8ToString( results.pItems[iPos], retTable.m_strlstCols.back() );
			else retTable.m_strlstCols.back().push_back(_T('\0'));
		}

		retTable.m_lstRows.resize(iRows);
		for (int iRow=0; iRow<iRows; iRow++)
		{
			retTable.m_lstRows[iRow].reserve(iCols);
			for (int iCol=0; iCol<iCols; iCol++)
			{
				// Add a string element
				retTable.m_lstRows[iRow].push_back(stdvstring());

				// Convert the UTF8 to TCHAR string
				if (results.pItems[iPos])
					ConvertUTF8ToString( results.pItems[iPos], retTable.m_lstRows[iRow].back() );
				else retTable.m_lstRows[iRow].back().push_back(_T('\0'));

				iPos++;
			}
		}
	}
	delete [] results.pItems;

#ifdef _DEBUG
	VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery: length in ms-%d\n"), GetTickCount()-iTick);
#endif
	return retTable;
}

CSQLiteTablePtr CSQLiteClient::sqliteQuery2(const TCHAR * strSQL)
{
#ifdef _DEBUG
	int iTick=GetTickCount();
#endif
	int iErr=0,iRows=0,iCols=0;
	char * errmsg=0;
	STACK_StrArray results={0,0};
	int iRes=svc_sqlite_get_table(UTF8MBSTR(strSQL), &iErr, &errmsg,
		&iRows, &iCols, &results);

	if (iRes!=SOCKET_STACK_OK)
	{
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery2(): Error %d, %s\n"), iRes, CSocketStack::GetErrorMessageStr(iRes));
		if (iRes==SOCKET_STACK_SEND_ERROR || iRes==SOCKET_STACK_CONNECT_ERROR)
		{
			Disconnect();
		}
	}
	if (iErr)
	{
		m_iLastError=iErr;
		if (m_strLastError) 
		{
			delete [] m_strLastError;
			m_strLastError=0;
		}
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery2(): SQLite error %d\n"), iErr);
	}
	if (errmsg) 
	{
		int iLen=(int)strlen(errmsg);
		UTF8MBSTR::ConvertUTF8ToString(errmsg, iLen+1, m_strLastError);
		free(errmsg);
		VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery2(): SQLite error %s\n"), m_strLastError);
	}

	CSQLiteTable * retTable = new CSQLiteTable();

	if (results.pItems)
	{
		if (iRows>0) retTable->m_iPos=0; // Put retTable's cursor on first row
		retTable->m_iCols=iCols;
		retTable->m_iRows=iRows;

		// allocate the memory for the header
		retTable->m_strlstCols.reserve(iCols);

		int iPos=0;

		for (; iPos<iCols; iPos++)
		{
			// Add a string element
			retTable->m_strlstCols.push_back(stdvstring());

			// Convert the UTF8 to TCHAR string
			if (results.pItems[iPos])
				ConvertUTF8ToString( results.pItems[iPos], retTable->m_strlstCols.back() );
			else retTable->m_strlstCols.back().push_back(_T('\0'));
		}

		retTable->m_lstRows.resize(iRows);
		for (int iRow=0; iRow<iRows; iRow++)
		{
			retTable->m_lstRows[iRow].reserve(iCols);
			for (int iCol=0; iCol<iCols; iCol++)
			{
				// Add a string element
				retTable->m_lstRows[iRow].push_back(stdvstring());

				// Convert the UTF8 to TCHAR string
				if (results.pItems[iPos])
					ConvertUTF8ToString( results.pItems[iPos], retTable->m_lstRows[iRow].back() );
				else retTable->m_lstRows[iRow].back().push_back(_T('\0'));

				iPos++;
			}
		}
	}
	delete [] results.pItems;

#ifdef _DEBUG
	VERBOSE_TRACE(_T("CSQLiteClient::sqliteQuery2: length in ms-%d\n"), GetTickCount()-iTick);
#endif
	return CSQLiteTablePtr(retTable);
}

int CSQLiteClient::svc_auth(STACK_Str in_user, STACK_Str in_pass)
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_auth);

	cStack.WriteStr(in_user);
	cStack.WriteStr(in_pass);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK) iRes = cStack.ReadInt();

	return iRes;
}

int CSQLiteClient::svc_sqlite_open(STACK_Str in_filename, 
								   STACK_Int in_mode /*= SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE*/,
								   STACK_Int *out_errcode/*=0*/, STACK_Str *out_errmsg/*=0*/)
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_open);

	cStack.WriteStr(in_filename);
	cStack.WriteInt(in_mode);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK)
	{
		iRes = cStack.ReadInt();
		if (iRes == SOCKET_STACK_OK)
		{
			if (out_errcode != 0) (*out_errcode) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
			if (out_errmsg != 0) (*out_errmsg) = _strdup(cStack.ReadStr());
			else cStack.ReadStr(); // Skip parameter
		}
	}
	return iRes;
}

int CSQLiteClient::svc_sqlite_close()
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_close);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK) iRes = cStack.ReadInt();

	return iRes;
}

int CSQLiteClient::svc_sqlite_changes(STACK_Int *out_count/*=0*/)
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_changes);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK)
	{
		iRes = cStack.ReadInt();
		if (iRes == SOCKET_STACK_OK)
		{
			if (out_count != 0) (*out_count) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
		}
	}
	return iRes;
}

int CSQLiteClient::svc_sqlite_last_insert_rowid(STACK_Int *out_rowid/*=0*/)
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_last_insert_rowid);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK)
	{
		iRes = cStack.ReadInt();
		if (iRes == SOCKET_STACK_OK)
		{
			if (out_rowid != 0) (*out_rowid) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
		}
	}
	return iRes;
}

int CSQLiteClient::svc_sqlite_interrupt()
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_interrupt);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK) iRes = cStack.ReadInt();

	return iRes;
}

int CSQLiteClient::svc_sqlite_libversion(STACK_Str *out_version/*=0*/)
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_libversion);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK)
	{
		iRes = cStack.ReadInt();
		if (iRes == SOCKET_STACK_OK)
		{
			if (out_version != 0) (*out_version) = _strdup(cStack.ReadStr());
			else cStack.ReadStr(); // Skip parameter
		}
	}
	return iRes;
}

int CSQLiteClient::svc_sqlite_exec(STACK_Str in_sql, 
								   STACK_Int *out_errcode/*=0*/, STACK_Str *out_errmsg/*=0*/)
{
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_exec);

	cStack.WriteStr(in_sql);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK)
	{
		iRes = cStack.ReadInt();
		if (iRes == SOCKET_STACK_OK)
		{
			if (out_errcode != 0) (*out_errcode) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
			if (out_errmsg != 0) (*out_errmsg) = _strdup(cStack.ReadStr());
			else cStack.ReadStr(); // Skip parameter
		}
	}
	return iRes;
}

int CSQLiteClient::svc_sqlite_get_table(STACK_Str in_sql, 
		STACK_Int *out_errcode/*=0*/, STACK_Str *out_errmsg/*=0*/,
		STACK_Int *out_rows/*=0*/, STACK_Int *out_cols/*=0*/, STACK_StrArray *out_results/*=0*/)
{
#ifdef _DEBUG
	int iTick=GetTickCount();
#endif
	if (!IsConnected()) return SOCKET_STACK_CONNECT_ERROR;

	static CSocketStack cStack;
	cStack.Reset();

	cStack.WriteByte(METHOD_sqlite_get_table);

	cStack.WriteStr(in_sql);

	int iRes = (cStack.Invoke(m_sockfd));

	if (iRes == SOCKET_STACK_OK)
	{
		iRes = cStack.ReadInt();
		if (iRes == SOCKET_STACK_OK)
		{
			if (out_errcode != 0) (*out_errcode) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
			if (out_errmsg != 0) (*out_errmsg) = _strdup(cStack.ReadStr());
			else cStack.ReadStr(); // Skip parameter
			if (out_rows != 0) (*out_rows) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
			if (out_cols != 0) (*out_cols) = cStack.ReadInt();
			else cStack.ReadInt(); // Skip parameter
			if (out_results != 0) (*out_results) = cStack.ReadStrArray();
			else cStack.ReadStrArray(); // Skip parameter
		}
	}
#ifdef _DEBUG
	VERBOSE_TRACE(_T("CSQLiteClient::svc_sqlite_get_table: length in ms-%d\n"), GetTickCount()-iTick);
#endif
	return iRes;
}

void CSQLiteClient::ConvertUTF8ToString( char * strInUTF8MB, stdvstring & strOut )
{
	int len=(int)strlen(strInUTF8MB)+1;
	strOut.resize(len, 0);

#ifdef UNICODE
	MultiByteToWideChar(CP_UTF8, 0, strInUTF8MB, len, &strOut[0], len);
#else
	WCHAR * wChar=new WCHAR[len];
	wChar[0]=0;
	MultiByteToWideChar(CP_UTF8, 0, strInUTF8MB, len, wChar, len);
	WideCharToMultiByte(CP_ACP, 0, wChar, len, &strOut[0], len, 0, 0);
	delete [] wChar;
#endif
}