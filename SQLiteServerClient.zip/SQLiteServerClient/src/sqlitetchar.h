/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#pragma once

#include <string>
#include <wtypes.h>

// Typedef for string
typedef std::basic_string<TCHAR> stdstring;

// Class for converting TCHAR to Multi-Byte UTF-8
//   and vice versa
class UTF8MBSTR
{
public:
	UTF8MBSTR(void);
	UTF8MBSTR( LPCTSTR lpStr );
	UTF8MBSTR( UTF8MBSTR& lpStr );
	virtual ~UTF8MBSTR();

	void operator =( LPCTSTR lpStr );
	void operator =( UTF8MBSTR& lpStr );
	operator char* ();
	operator stdstring ();

	static size_t ConvertStringToUTF8( LPCTSTR strIn, char *& strOutUTF8MB );
	static void ConvertUTF8ToString( char * strInUTF8MB, size_t len, LPTSTR & strOut );

private:
	char * m_strUTF8_MultiByte;

	size_t m_iLen;
};