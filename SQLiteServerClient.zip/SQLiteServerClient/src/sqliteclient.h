/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#pragma once

#include "socketstack.h"
#include "sqlitetable.h"

#define SQLITE_SERVER_DEFAULT_PORT 1278


#define SQLITE_OPEN_READONLY         0x00000001
#define SQLITE_OPEN_READWRITE        0x00000002
#define SQLITE_OPEN_CREATE           0x00000004
#define SQLITE_OPEN_DELETEONCLOSE    0x00000008
#define SQLITE_OPEN_EXCLUSIVE        0x00000010
#define SQLITE_OPEN_MAIN_DB          0x00000100
#define SQLITE_OPEN_TEMP_DB          0x00000200
#define SQLITE_OPEN_TRANSIENT_DB     0x00000400
#define SQLITE_OPEN_MAIN_JOURNAL     0x00000800
#define SQLITE_OPEN_TEMP_JOURNAL     0x00001000
#define SQLITE_OPEN_SUBJOURNAL       0x00002000
#define SQLITE_OPEN_MASTER_JOURNAL   0x00004000

#define SQLITE_OK           0   /* Successful result */
/* beginning-of-error-codes */
#define SQLITE_ERROR        1   /* SQL error or missing database */
#define SQLITE_INTERNAL     2   /* Internal logic error in SQLite */
#define SQLITE_PERM         3   /* Access permission denied */
#define SQLITE_ABORT        4   /* Callback routine requested an abort */
#define SQLITE_BUSY         5   /* The database file is locked */
#define SQLITE_LOCKED       6   /* A table in the database is locked */
#define SQLITE_NOMEM        7   /* A malloc() failed */
#define SQLITE_READONLY     8   /* Attempt to write a readonly database */
#define SQLITE_INTERRUPT    9   /* Operation terminated by sqlite3_interrupt()*/
#define SQLITE_IOERR       10   /* Some kind of disk I/O error occurred */
#define SQLITE_CORRUPT     11   /* The database disk image is malformed */
#define SQLITE_NOTFOUND    12   /* NOT USED. Table or record not found */
#define SQLITE_FULL        13   /* Insertion failed because database is full */
#define SQLITE_CANTOPEN    14   /* Unable to open the database file */
#define SQLITE_PROTOCOL    15   /* NOT USED. Database lock protocol error */
#define SQLITE_EMPTY       16   /* Database is empty */
#define SQLITE_SCHEMA      17   /* The database schema changed */
#define SQLITE_TOOBIG      18   /* String or BLOB exceeds size limit */
#define SQLITE_CONSTRAINT  19   /* Abort due to constraint violation */
#define SQLITE_MISMATCH    20   /* Data type mismatch */
#define SQLITE_MISUSE      21   /* Library used incorrectly */
#define SQLITE_NOLFS       22   /* Uses OS features not supported on host */
#define SQLITE_AUTH        23   /* Authorization denied */
#define SQLITE_FORMAT      24   /* Auxiliary database format error */
#define SQLITE_RANGE       25   /* 2nd parameter to sqlite3_bind out of range */
#define SQLITE_NOTADB      26   /* File opened that is not a database file */
#define SQLITE_ROW         100  /* sqlite3_step() has another row ready */
#define SQLITE_DONE        101  /* sqlite3_step() has finished executing */
/* end-of-error-codes */

class CSQLiteClient
{
public:
	CSQLiteClient();
	~CSQLiteClient();

	static int InitSockets();
	static int UninitSockets();

	bool Connect(const TCHAR * strHost, unsigned short sPort);
	bool Connect();
	void Disconnect();
	bool IsConnected();

	bool SetPort(unsigned short sPort);
	unsigned short GetPort();

	void SetHost(const TCHAR * strHost);
	TCHAR * GetHost();

	int GetLastError();
	TCHAR * GetLastErrorString();
	void ClearLastError();

	// * Sends an authentication request.
	// * Returns true if the username and password exists, and have any rights
	bool sqliteAuth(const TCHAR * strUser, const TCHAR * strPass);

	// * Sends an sqlite3_open.
	// * Returns true if successfull
	bool sqliteOpen(const TCHAR * strFileName, 
		int in_mode = SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE);

	// * Sends an sqlite3_close.
	void sqliteClose();

	// * Sends an sqlite3_changes. 
	// * Returns -1 if an error occurred.
	int sqliteChanges();

	// * Sends an sqlite3_last_insert_rowid. 
	// * Returns -1 if an error occurred.
	int sqliteLastInsertRowID();

	// * Sends an sqlite3_interrupt.
	// * Returns true if successfull
	bool sqliteInterrupt();

	// * Sends an sqlite3_libversion.
	// * Returns NULL if an error occurred.
	// * You must free the result with delete[] !
	TCHAR * sqliteLibVersion();

	// * Sends an sqlite3_exec.
	// * Returns true if successfull
	bool sqliteExec(const TCHAR * strSQL);

	// * Sends an sqlite3_get_table.
	// * Returns a table within a CSQLiteTable class.
	// * If an error occurred, the table will be empty, no cols and no rows.
	CSQLiteTable sqliteQuery(const TCHAR * strSQL);

	// * Sends an sqlite3_get_table.
	// * Returns a table within a CSQLiteTablePtr class (to prevent copying of table).
	// * If an error occurred, the m_pTable member will be NULL.
	CSQLiteTablePtr sqliteQuery2(const TCHAR * strSQL);

private:
	// * Sends an authentication request.
	// * Return value: 0 mean success.
	int svc_auth(STACK_Str in_user, STACK_Str in_pass);

	// * Sends an sqlite3_open.
	// * Return value: 0 mean success.
	// * out_errmsg is allocated with _strdup() and must be freed with free() !
	int svc_sqlite_open(STACK_Str in_filename, 
		STACK_Int in_mode = SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE,
		STACK_Int *out_errcode = 0, STACK_Str *out_errmsg = 0);

	// * Sends an sqlite3_close.
	// * Return value: 0 mean success.
	int svc_sqlite_close();

	// * Sends an sqlite3_changes.
	// * Return value: 0 mean success.
	int svc_sqlite_changes(STACK_Int *out_count=0);

	// * Sends an sqlite3_last_insert_rowid.
	// * Return value: 0 mean success.
	int svc_sqlite_last_insert_rowid(STACK_Int *out_rowid=0);

	// * Sends an sqlite3_interrupt.
	// * Return value: 0 mean success.
	int svc_sqlite_interrupt();

	// * Sends an sqlite3_libversion.
	// * Return value: 0 mean success.
	// * out_version is allocated with _strdup() and must be freed with free() !
	int svc_sqlite_libversion(STACK_Str *out_version=0);

	// * Sends an sqlite3_exec.
	// * Return value: 0 mean success.
	// * out_errmsg is allocated with _strdup() and must be freed with free() !
	int svc_sqlite_exec(STACK_Str in_sql,
		STACK_Int *out_errcode=0, STACK_Str *out_errmsg=0);

	// * Sends an sqlite3_get_table.
	// * Return value: 0 mean success.
	// * out_errmsg is allocated with _strdup() and must be freed with free() !
	// * out_results->pItems must be freed with delete[] !
	int svc_sqlite_get_table(STACK_Str in_sql, 
		STACK_Int *out_errcode=0, STACK_Str *out_errmsg=0,
		STACK_Int *out_rows=0, STACK_Int *out_cols=0, STACK_StrArray *out_results=0);

private:
	SOCKET m_sockfd;
	struct addrinfo * m_pAddrInfo;
	unsigned short m_sPort;
	TCHAR * m_strHost;
	bool m_bConnected;
	int m_iLastError;
	TCHAR * m_strLastError;

	// Helper function to convert UTF8 straight into a string in the table.
	// Copied from my UTF8MBSTR class.
	void ConvertUTF8ToString( char * strInUTF8MB, stdvstring & strOut );
};
