/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#pragma once

#include "servermainthread.h"
#include "authinterface.h"
#include "connsinterface.h"
#include <list>

#define SQLITE_SERVER_DEFAULT_PORT 1278

class CSQLiteServer
{
public:
	CSQLiteServer();
	~CSQLiteServer();

	static int InitSockets();
	static int UninitSockets();

	bool Start(unsigned short sPort);
	bool Start();
	void Stop();

	bool SetServerPort(unsigned short sPort);
	unsigned short GetServerPort();

	void AddClientSocket(SOCKET sock);
	void RemoveClientSocket(SOCKET sock);
	void KillConnections();

	bool IsListening() const { return m_bRunning; };

	CAuthInterface * m_pAuthLayer; // Can set this to a user manager class
	CConnsInterface * m_pConnsLayer; // Can set this to a connection manager class

private:
	unsigned short m_sPort;
	bool m_bRunning;
	CServerMainThread * m_pServerMainThread;
	std::list<SOCKET> m_lstClientSockets;
};