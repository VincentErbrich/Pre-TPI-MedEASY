/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "socketstack.h"
#include "verbose.h"

CSocketStack::CSocketStack() : CSocketStream()
{
	m_pStreamHeader = new CSocketStream();
	m_iToGet=0;
}

CSocketStack::~CSocketStack()
{
	delete m_pStreamHeader;
}

const TCHAR* CSocketStack::GetErrorMessageStr(int iErr)
{
	switch (iErr)
	{
	case SOCKET_STACK_OK: return _T("No Error");
	case SOCKET_STACK_SEND_ERROR: return _T("Stack send error");
	case SOCKET_STACK_RECV_HEADER_ERROR : return _T("Stack receive header error");
	case SOCKET_STACK_RECV_BODY_ERROR: return _T("Stack receive body error");
	case SOCKET_STACK_ACCEPT_ERROR : return _T("Stack accept error");
	case SOCKET_STACK_CONNECT_ERROR : return _T("Stack connect error");
	case SOCKET_STACK_WRONG_FORMAT_OR_TOO_BIG: return _T("Stack wrong format or too big message");
	case SOCKET_STACK_SERVER_STUB_ERROR : return _T("Stack server stub error");
	case SOCKET_STACK_NOT_OPEN : return _T("No database is open.");
	case SOCKET_STACK_NO_RIGHTS : return _T("Connected user has insufficient permissions.");
	}

	if (iErr > SOCKET_STACK_USER_ERROR_BASE) return _T("Stack user error");
	return _T("Unknown stack error");
}

void CSocketStack::InsertHeader()
{
	m_pStreamHeader->Reset();
	int iBodyLength = GetPosition();
	m_pStreamHeader->WriteInt(iBodyLength);
	m_pStreamHeader->CopyStream(this);
	Reset();
	CopyStream(m_pStreamHeader);
}

void CSocketStack::ReadHeader()
{
	m_iToGet = ReadInt();
}

int CSocketStack::Invoke(SOCKET sock)
{
	int sent_res = SendMessage(sock);

	if (sent_res == SOCKET_STACK_OK) return RecvMessage(sock);
	else 
	{
		VERBOSE_TRACE(_T("invoke failed with %d\n"),sent_res);
		return sent_res;
	}
}

int CSocketStack::SendMessageBuffer(SOCKET sock)
{
	int sent = SendBuffer(sock);
	if (sent != GetPosition())
	{
		VERBOSE_TRACE(_T("CSocketStack::SendMessageBuffer(%d): Couldn't send message\n"), sock);
		return SOCKET_STACK_SEND_ERROR;
	}
	else
	{
		return SOCKET_STACK_OK;
	}
}

int CSocketStack::SendMessage(SOCKET sock)
{
	InsertHeader();
	return SendMessageBuffer(sock);
}


int CSocketStack::RecvMessage(SOCKET sock)
{
	Reset();
	int iReceived = RecvBuffer(sock,SOCKET_STACK_HEADER_SIZE);
	if (iReceived != SOCKET_STACK_HEADER_SIZE)
	{
		VERBOSE_TRACE(_T("CSocketStack::RecvMessage(%d): Couldn't receive header\n"), sock);
		return SOCKET_STACK_RECV_HEADER_ERROR;
	}
	Reset();

	ReadHeader();

	if (m_iToGet > SOCKET_STACK_MAX_SIZE)
	{
		return SOCKET_STACK_WRONG_FORMAT_OR_TOO_BIG;
	}

	CheckResize(m_iToGet);
	iReceived = RecvBuffer(sock,m_iToGet);
	m_iToGet -= iReceived;

	if (m_iToGet != 0)
	{
		VERBOSE_TRACE(_T("CSocketStack::RecvMessage(%d): Couldn't receive whole message\n"), sock);
		return SOCKET_STACK_RECV_BODY_ERROR;
	}
	Reset();

	// skip header
	ReadHeader();

	return SOCKET_STACK_OK;
}

STACK_StrArray CSocketStack::ReadStrArray()
{
	STACK_StrArray res;
	res.pItems = CSocketStream::ReadStrArray(&(res.iLen));
	return res;
}

void CSocketStack::WriteStrArray(const STACK_StrArray& strArray)
{
	CSocketStream::WriteStrArray(strArray.pItems,strArray.iLen);
}

