/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "servermainthread.h"
#include "clientconnection.h"
#include "handlerthread.h"
#include "verbose.h"
#include "sqliteserver.h"

CServerMainThread::CServerMainThread(CSQLiteServer * pParentServer/*=0*/)
{
	m_sPort=0;
	m_sockListen=0;
	m_bRunning=false;
	m_bError=false;
	m_pParentServer=pParentServer;
}

CServerMainThread::~CServerMainThread()
{
	if (m_bRunning) Kill();
}

bool CServerMainThread::Start(bool bAutoDelete/*=false*/)
{
	m_bError=false;
	return CThreadBase::Start(bAutoDelete);
}

void CServerMainThread::ExecuteThread()
{
	m_sockListen = socket_server(m_sPort);

	if (m_sockListen == INVALID_SOCKET)
	{
		VERBOSE_TRACE(_T("CServerMainThread::ExecuteThread(): Couldn't create socket for port %d\n"),m_sPort);
		m_bError=true;
		return;
	}
	else
	{
		VERBOSE_TRACE(_T("CServerMainThread::ExecuteThread(): Listening at port %d ...\n"),m_sPort);
	}

 	CClientConnection* pConnection;
 	CHandlerThread*    pHandler;

	m_bRunning = true;

	while (m_bRunning)
	{
 		pConnection = new CClientConnection(m_sockListen);
 		if (pConnection->Accept() != INVALID_SOCKET)
 		{
			if (m_pParentServer) 
			{
				pConnection->m_pParentServer=m_pParentServer;
				m_pParentServer->AddClientSocket(pConnection->m_sockNew);
			}
			VERBOSE_TRACE(_T("CServerMainThread::ExecuteThread(): Creating thread...\n"));
 			pHandler = new CHandlerThread(pConnection, m_pParentServer);
 			if (!pHandler->Start(true))
			{
				delete pConnection;
				pConnection=0;
			}
 		}
 		else
 		{
 			delete pConnection;
			if (m_sockListen==0) m_bRunning=false;
 		}
		// The thread deletes the connection, no need to worry
	}

	if (m_sockListen) socket_close(m_sockListen);
	m_sockListen=0;

	m_bRunning=false;
}

void CServerMainThread::Kill()
{
	if (m_hThread) 
	{
		m_bRunning=false;
		socket_close(m_sockListen);
		m_sockListen=0;
		Stop();
	}
}

bool CServerMainThread::SetPort(unsigned short sPort)
{
	if (m_bRunning) return false;
	else {
		m_sPort=sPort;
		return true;
	}
}

unsigned short CServerMainThread::GetPort()
{
	return m_sPort;
}
