/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "socketstream.h"
#include <assert.h>

CSocketStream::CSocketStream()
{
	InitBuffer();
}

CSocketStream::~CSocketStream()
{
	delete [] m_strBase;
}

void CSocketStream::InitBuffer()
{
	m_strBase = new char[SOCKET_STREAM_BUFFER_STEP];
	assert(m_strBase);
	m_pPos  = m_strBase;
	m_iSize = SOCKET_STREAM_BUFFER_STEP;
}

void CSocketStream::Reset()
{
	m_pPos = m_strBase;
}

int CSocketStream::GetBufferSize()
{
	return m_iSize;
}

void CSocketStream::CopyStream(CSocketStream* stream)
{
	int source_len = stream->GetPosition();
	CheckResize(source_len);
	memcpy(m_pPos,stream->m_strBase,source_len);
	m_pPos += source_len;
}

void CSocketStream::CheckResize(int iCheckLen)
{
	int iCurLength = (int)(m_pPos-m_strBase);
	if (m_iSize-iCurLength < iCheckLen)
	{
		int iNewSize = m_iSize;
		while (iNewSize-iCurLength < iCheckLen) iNewSize+=SOCKET_STREAM_BUFFER_STEP;
		char* strNewStack = new char[iNewSize];
		assert(strNewStack);
		memcpy(strNewStack,m_strBase,m_iSize);
		m_pPos = strNewStack+iCurLength;
		delete[] m_strBase;
		m_strBase = strNewStack;
		m_iSize = iNewSize;
	}
}

void CSocketStream::SetPosition(int iPosition)
{
	m_pPos = m_strBase+iPosition;
}

int CSocketStream::GetPosition()
{
	return (int)(m_pPos-m_strBase);
}

void CSocketStream::WriteByte(unsigned char b)
{
	CheckResize(1);
	*m_pPos = b;
	m_pPos++;
}

void CSocketStream::WriteInt(int i)
{
	CheckResize(sizeof(int));
	*((int*)m_pPos) = i;
	m_pPos+=sizeof(int);
}

void CSocketStream::WriteStr(char* str)
{
	if (str == 0)
	{
		WriteByte(0);
		return;
	}
	int iLen = (int)strlen(str)+1;
	if (iLen<254)
	{
		WriteByte(iLen);
	}
	else
	{
		WriteByte(255);
		WriteInt(iLen);
	}

	CheckResize(iLen);
	memcpy(m_pPos,str,iLen);
	m_pPos+=iLen;
}

void CSocketStream::WriteStrArray(char **strArray, int iLen)
{
	WriteInt(iLen);
	for (int i=0;i<iLen;i++)
	{
		WriteStr(strArray[i]);
	}
}

unsigned char CSocketStream::ReadByte()
{
	assert(m_pPos < m_strBase+m_iSize);
	unsigned char c = *m_pPos;
	m_pPos++;
	return c;
}

int CSocketStream::ReadInt()
{
	assert(m_pPos < m_strBase+m_iSize);
	int iRes = *((int*)m_pPos);
	m_pPos+=sizeof(int);
	return iRes;
}

char* CSocketStream::ReadStr()
{
	unsigned char bLen = ReadByte();
	int iRealLen;
	if (bLen == 0) return 0;
	if ((unsigned char)bLen == (unsigned char)255) iRealLen=ReadInt();
	else iRealLen = (int)bLen;
	assert(m_pPos < m_strBase+m_iSize);
	char* pRes = m_pPos;
	m_pPos+=iRealLen;
	return pRes;
}

char** CSocketStream::ReadStrArray(int * iLen)
{
	*iLen = ReadInt();
	char **ppchar = new char*[*iLen];
	for(int i=0;i<*iLen;i++)
	{
		ppchar[i] = ReadStr();
	}
	return ppchar;
}

int CSocketStream::SendBuffer(SOCKET socket)
{
	return send(socket,m_strBase,(int)(m_pPos-m_strBase),0);
}

int CSocketStream::RecvBuffer(SOCKET socket, int iMaxLen)
{
	CheckResize(iMaxLen);

	// MSG_WAITALL for some reason doesnt work, returns -1,
	// So I have to implement blocking recv() myself
	//
	// FIX: If recv(...) returns 0, it means the connection 
	//   was closed gracefully by the client
	m_iRecvBufferRet=0;
	m_iRecvBufferCount=0;
	do 
	{
		m_iRecvBufferRet=recv(socket,m_pPos+m_iRecvBufferCount,iMaxLen,0);
		if (m_iRecvBufferRet>0) {
			m_iRecvBufferCount+=m_iRecvBufferRet;
			iMaxLen-=m_iRecvBufferRet;
		}
	} while (m_iRecvBufferRet>0 && m_iRecvBufferRet<iMaxLen);
	return m_iRecvBufferCount;
}
