/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "threadbase.h"

DWORD WINAPI ThreadProc(LPVOID param)
{
	CThreadBase * thread = (CThreadBase *) param;
	thread->ExecuteThread();
	CloseHandle(thread->m_hThread);
	thread->m_hThread=0;
	thread->m_dwThread=0;
	if (thread->m_bAutoDelete) delete thread;
	return 0;
}

CThreadBase::CThreadBase()
{
	m_hThread=0;
	m_dwThread=0;
	m_bAutoDelete=false;
}

CThreadBase::~CThreadBase()
{
	Stop();
}

void CThreadBase::Stop()
{
	if (m_hThread!=0)
	{
		if (WaitForSingleObject(m_hThread, MAX_WAIT_THREAD_CLOSE)!=WAIT_OBJECT_0)
		{
			DWORD dwExit=0;
			GetExitCodeThread(m_hThread, &dwExit);
			TerminateThread(m_hThread, dwExit);
			CloseHandle(m_hThread);
		}
		m_hThread=0;
		m_dwThread=0;
	}
}

bool CThreadBase::Start(bool bAutoDelete/*=false*/)
{
	if (m_hThread) return false;
	m_bAutoDelete=bAutoDelete;
	return (m_hThread = CreateThread(NULL, 0, ThreadProc, this, 0, &m_dwThread))!=0;
}

bool CThreadBase::SetPriority(ThreadPriority priority)
{
	int iPriority = THREAD_PRIORITY_NORMAL;
	switch (priority)
	{
	case prIdle:
		iPriority = THREAD_PRIORITY_IDLE;
		break;
	case prLower:
		iPriority = THREAD_PRIORITY_BELOW_NORMAL;
		break;
	case prHigher:
		iPriority = THREAD_PRIORITY_ABOVE_NORMAL;
		break;
	case prHighest:
		iPriority = THREAD_PRIORITY_HIGHEST;
		break;
	}

	return SetThreadPriority(m_hThread, iPriority)==TRUE;
}
