/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#pragma once

#include <wtypes.h>

// CSQLiteTable and CSQLiteTablePtr are taken from my SQLite wrapper library,
// and changed the names of the classes

#include <vector>

// I use this one for a sequential array in memory,
//   So I can write directly to it
typedef std::vector<TCHAR> stdvstring; 
typedef std::vector<stdvstring> vstrlist;
typedef vstrlist row;

// SQLiteTable class...
//
// I did not implement deleting rows from the table,
//   because I do no think there will be use for it, at least for me.
//   for delete records, use SQL... :-)
// If you still want to implement this, change [m_lstRows] from vector to list
//   and update [m_iRows] each time you delete a row.
class CSQLiteTable
{
	friend class CSQLiteClient; // I allow Database class to enter data directly.
public:
	CSQLiteTable(void){ m_iRows=m_iCols=0;	m_iPos=-1; };
	virtual ~CSQLiteTable() {};


	// Gets the number of columns
	int GetColCount(){ if (this==0) return 0; return m_iCols; };

	// Gets the number of rows
	int GetRowCount(){ if (this==0) return 0; return m_iRows; };

	// Gets the current selected row. -1 when no rows exists.
	int GetCurRow(){ if (this==0) return -1; return m_iPos; };

	// Gets the column name at m_iCol index.
	// Returns null if the index is out of bounds.
	LPCTSTR GetColName( int iCol );

	// Sets the 'iterator' to the first row
	// returns false if fails (no records)
	bool GoFirst();

	// Sets the 'iterator' to the last row
	// returns false if fails (no records)
	bool GoLast();

	// Sets the 'iterator' to the next row
	// returns false if fails (reached end)
	bool GoNext();

	// Sets the 'iterator' to the previous row
	// returns false if fails (reached beginning)
	bool GoPrev();

	// Sets the 'iterator' to the [iRow] row
	// returns false if fails (out of bounds)
	bool GoRow(unsigned int iRow);

	// Gets the value of lpColName column, in the current row
	// returns null if fails (no records)
	LPCTSTR GetValue(LPCTSTR lpColName);

	// Gets the value of iColIndex column, in the current row
	// returns null if fails (no records)
	LPCTSTR GetValue(int iColIndex);

	// Gets the value of lpColName column, in the current row
	// returns null if fails (no records)
	LPCTSTR operator [] (LPCTSTR lpColName);

	// Gets the value of iColIndex column, in the current row
	// returns null if fails (no records)
	LPCTSTR operator [] (int iColIndex);

	// Adds the rows from another table to this table
	// It is the caller's reponsibility to make sure
	// The two tables are matching
	void JoinTable(CSQLiteTable & tblJoin);

private:
	int m_iRows, m_iCols;

	row m_strlstCols;
	std::vector<row> m_lstRows;

	int m_iPos;
};

// A class to contain a pointer to a CSQLiteTable class,
// Which will spare the user from freeing a pointer.
class CSQLiteTablePtr
{
public:
	// Default constructor
	CSQLiteTablePtr( );

	// Construct from a Table*
	CSQLiteTablePtr( CSQLiteTable * pTable );

	// Copy constructor.
	// Will prevent the original TablePtr from deleting the table.
	// If you have a previous table connected to this class,
	//   you do not have to worry, 
	//   it will commit suicide before eating the new table.
	CSQLiteTablePtr( const CSQLiteTablePtr& cTablePtr );

	// Destructor...
	virtual ~CSQLiteTablePtr();

	// Copy operator.
	// Will prevent the original TablePtr from deleting the table.
	// If you have a previous table connected to this class,
	//   you do not have to worry, 
	//   it will commit suicide before eating the new table.
	void operator =( const CSQLiteTablePtr& cTablePtr );

	// Functor operator, will de-reference the m_pTable member.
	// WARNING: Use with care! Check for non-null m_pTable first!
	CSQLiteTable& operator()(){ return *m_pTable; };

	// bool operator, to check if m_pTable is valid.
	operator bool(){ return m_pTable!=0; };

	// Detaches the class from the Table,
	// and returns the Table that were just detached...
	CSQLiteTable * Detach();

	// Frees the current Table, and attaches the pTable.
	void Attach( CSQLiteTable * pTable );

	// Frees the current Table.
	void Destroy();

	// Pointer to the table.
	// I do not see any reason for encapsulating in Get/Set functions.
	CSQLiteTable * m_pTable;
};
