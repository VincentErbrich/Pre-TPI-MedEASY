/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "sqlitetchar.h"
#include <winnls.h> // Encodings

UTF8MBSTR::UTF8MBSTR()
{
	m_strUTF8_MultiByte=new char[1];
	m_strUTF8_MultiByte[0]=0;
	m_iLen=0;
}

UTF8MBSTR::UTF8MBSTR( LPCTSTR lpStr )
{
	if (lpStr)
		m_iLen=ConvertStringToUTF8(lpStr, m_strUTF8_MultiByte);
	else {
		m_strUTF8_MultiByte=new char[1];
		m_strUTF8_MultiByte[0]=0;
		m_iLen=0;
	}
}

UTF8MBSTR::UTF8MBSTR( UTF8MBSTR& lpStr )
{
	m_iLen=lpStr.m_iLen;
	m_strUTF8_MultiByte=new char[m_iLen+1];
	strncpy_s(m_strUTF8_MultiByte, m_iLen+1, lpStr.m_strUTF8_MultiByte, m_iLen+1);
}

UTF8MBSTR::~UTF8MBSTR()
{
	if (m_strUTF8_MultiByte)
	{
		delete [] m_strUTF8_MultiByte;
	}
}

void UTF8MBSTR::operator =( LPCTSTR lpStr )
{
	if (m_strUTF8_MultiByte)
	{
		delete [] m_strUTF8_MultiByte;
	}
	if (lpStr)
		m_iLen=ConvertStringToUTF8(lpStr, m_strUTF8_MultiByte);
	else {
		m_strUTF8_MultiByte=new char[1];
		m_strUTF8_MultiByte[0]=0;
		m_iLen=0;
	}
}

void UTF8MBSTR::operator =( UTF8MBSTR& lpStr )
{
	if (m_strUTF8_MultiByte)
	{
		delete [] m_strUTF8_MultiByte;
	}
	m_iLen=lpStr.m_iLen;
	m_strUTF8_MultiByte=new char[m_iLen+1];
	strncpy_s(m_strUTF8_MultiByte, m_iLen+1, lpStr.m_strUTF8_MultiByte, m_iLen+1);
}

UTF8MBSTR::operator char* ()
{
	return m_strUTF8_MultiByte;
}

UTF8MBSTR::operator stdstring ()
{
	TCHAR * strRet;
	ConvertUTF8ToString(m_strUTF8_MultiByte, m_iLen+1, strRet);

	stdstring cstrRet(strRet);

	delete [] strRet;

	return cstrRet;
}

size_t UTF8MBSTR::ConvertStringToUTF8( LPCTSTR strIn, char *& strOutUTF8MB )
{
	size_t len=_tcslen(strIn);

#ifdef UNICODE
	int iRequiredSize=WideCharToMultiByte(CP_UTF8, 0, strIn, (int)len+1, 0, 0, 0, 0);

	strOutUTF8MB=new char[iRequiredSize];
	strOutUTF8MB[0]=0;

	WideCharToMultiByte(CP_UTF8, 0, strIn, (int)len+1, strOutUTF8MB, iRequiredSize, 0, 0);
#else
	WCHAR * wChar=new WCHAR[len+1];
	wChar[0]=0;
	MultiByteToWideChar(CP_ACP, 0, strIn, (int)len+1, wChar, (int)len+1);
	int iRequiredSize=WideCharToMultiByte(CP_UTF8, 0, wChar, (int)len+1, 0, 0, 0, 0);
	strOutUTF8MB=new char[iRequiredSize];
	strOutUTF8MB[0]=0;
	WideCharToMultiByte(CP_UTF8, 0, wChar, (int)len+1, strOutUTF8MB, iRequiredSize, 0, 0);
	delete [] wChar;
#endif

	return len;
}

void UTF8MBSTR::ConvertUTF8ToString( char * strInUTF8MB, size_t len, LPTSTR & strOut )
{
	strOut=new TCHAR[len];
	strOut[0]=0;

#ifdef UNICODE
	MultiByteToWideChar(CP_UTF8, 0, strInUTF8MB, (int)len, strOut, (int)len);
#else
	WCHAR * wChar=new WCHAR[len];
	wChar[0]=0;
	MultiByteToWideChar(CP_UTF8, 0, strInUTF8MB, (int)len, wChar, (int)len);
	WideCharToMultiByte(CP_ACP, 0, wChar, (int)len, strOut, (int)len, 0, 0);
	delete [] wChar;
#endif
}