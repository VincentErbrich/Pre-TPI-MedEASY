/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "sqliteserver.h"
#include "servermainthread.h"
#include "socket.h"
#include "verbose.h"

CSQLiteServer::CSQLiteServer()
{
	m_sPort=SQLITE_SERVER_DEFAULT_PORT;
	m_bRunning=false;
	m_pServerMainThread=0;
	m_pAuthLayer=0;
	m_pConnsLayer=0;
}

CSQLiteServer::~CSQLiteServer()
{
	if (m_bRunning) Stop();
}

int CSQLiteServer::InitSockets()
{
	return socket_init();
}

int CSQLiteServer::UninitSockets()
{
	return socket_uninit();
}

bool CSQLiteServer::Start(unsigned short sPort)
{
	if (m_bRunning) return false;

	m_sPort=sPort;
	return Start();
}

bool CSQLiteServer::Start()
{
	if (m_bRunning) return false;
	m_bRunning=true;

	m_pServerMainThread=new CServerMainThread(this);
	m_pServerMainThread->SetPort(m_sPort);
	if (m_pServerMainThread->Start())
	{
		int iTryCount=10;
		while (!m_pServerMainThread->IsRunning() && !m_pServerMainThread->IsError() && iTryCount>0)
		{
			Sleep(100);
			iTryCount--;
		}
		if (m_pServerMainThread->IsRunning()) return true;
		else 
		{
			delete m_pServerMainThread;
			m_pServerMainThread=0;
			m_bRunning=false;
			return false;
		}
	} else {
		delete m_pServerMainThread;
		m_pServerMainThread=0;
		m_bRunning=false;
		return false;
	}
}

void CSQLiteServer::Stop()
{
	if (!m_bRunning) return;

	if (m_pServerMainThread) delete m_pServerMainThread;
	m_pServerMainThread=0;

	m_bRunning=false;
}

bool CSQLiteServer::SetServerPort(unsigned short sPort)
{
	if (m_bRunning) return false;
	else {
		m_sPort=sPort;
		return true;
	}
}

unsigned short CSQLiteServer::GetServerPort()
{
	return m_sPort;
}

void CSQLiteServer::KillConnections()
{
	std::list<SOCKET> lstClientSockets=m_lstClientSockets;
	m_lstClientSockets.clear();
	for (std::list<SOCKET>::iterator pos=lstClientSockets.begin();
		pos!=lstClientSockets.end(); pos++)
	{
		socket_close(*pos);
		if (m_pConnsLayer) m_pConnsLayer->ConnectionDropped(*pos);
	}
}

void CSQLiteServer::AddClientSocket(SOCKET sock)
{
	m_lstClientSockets.push_back(sock);
	if (m_pConnsLayer) m_pConnsLayer->NewConnection(sock);
}

void CSQLiteServer::RemoveClientSocket(SOCKET sock)
{
	m_lstClientSockets.remove(sock);
	if (m_pConnsLayer) m_pConnsLayer->ConnectionDropped(sock);
}