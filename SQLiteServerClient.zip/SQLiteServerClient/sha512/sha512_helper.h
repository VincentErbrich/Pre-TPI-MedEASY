#pragma once

#include <tchar.h>

#include "sha512.h"

int HashString(const TCHAR * pStr, unsigned char (&outHash)[SHA512_DIGEST_SIZE], int iStrLen=-1);
int HashStringToHex(const TCHAR * pStr, TCHAR (&outChars)[SHA512_DIGEST_SIZE*2+1], int iStrLen=-1);
