#include <stdio.h>

#include "sha512_helper.h"

int HashString(const TCHAR * pStr, unsigned char (&outHash)[SHA512_DIGEST_SIZE], int iStrLen/*=-1*/)
{
	if (pStr==0) return -1;
	else
	{
		sha512_ctx sha512;
		if (iStrLen<0) iStrLen=(int)_tcslen(pStr);

		sha512_begin(&sha512);
		sha512_hash((const unsigned char*)pStr, iStrLen*sizeof(TCHAR), &sha512);
		sha512_end(outHash, &sha512);
	}

	return 0;
}

int HashStringToHex(const TCHAR * pStr, TCHAR (&outChars)[SHA512_DIGEST_SIZE*2+1], int iStrLen/*=-1*/)
{
	if (pStr==0) return -1;
	else
	{
		sha512_ctx sha512;
		if (iStrLen<0) iStrLen=(int)_tcslen(pStr);
		unsigned char sha[SHA512_DIGEST_SIZE];

		sha512_begin(&sha512);
		sha512_hash((const unsigned char*)pStr, iStrLen*sizeof(TCHAR), &sha512);
		sha512_end(sha, &sha512);

		for (int i=0; i<64; i++)
		{
			_itot_s(sha[i], &outChars[i*2], 3, 16);
			if (outChars[i*2+1]==0)
			{
				outChars[i*2+1]=outChars[i*2];
				outChars[i*2]=_T('0');
			}
		}
	}

	return 0;
}
