//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SQLite_Server.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_SQLITE_SERVER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDR_CONTEXT                     129
#define IDI_SMALLICON                   130
#define IDD_SQLITE_SERVER_PAGE1         132
#define IDD_SQLITE_SERVER_PAGE2         133
#define IDC_START                       1000
#define IDC_STOP                        1001
#define IDC_BUTTON3                     1002
#define IDC_KILLALL                     1002
#define IDC_LIST_USERS                  1003
#define IDC_USER                        1004
#define IDC_PASS                        1005
#define IDC_PERM_READ                   1006
#define IDC_PERM_WRITE                  1007
#define IDC_PERM_CREATEDB               1008
#define IDC_ADD_USER                    1009
#define IDC_MINIMIZE                    1010
#define IDC_DELETE_USER                 1011
#define IDC_EXIT                        1012
#define IDC_PORT                        1013
#define IDC_TAB                         1015
#define IDC_LIST_CONNS                  1016
#define IDC_KILL                        1017
#define ID_TRAYCONTEXT_SHOW             32771
#define ID_TRAYCONTEXT_EXIT             32772
#define ID_TRAYCONTEXT_STARTLISTENING   32773
#define ID_TRAYCONTEXT_STOPLISTENING    32774
#define ID_TRAYCONTEXT_KILLCONNECTIONS  32775
#define ID_SHOW                         32776
#define ID_STARTLISTENING               32777
#define ID_STOPLISTENING                32778
#define ID_KILLCONNECTIONS              32779
#define ID_CANCEL                       32780
#define ID_EXIT                         32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
