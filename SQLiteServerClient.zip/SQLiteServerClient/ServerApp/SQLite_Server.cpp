// SQLite_Server.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "SQLite_Server.h"
#include "../src/sqliteserver.h"
#include "INIAuth.h"
#include "ConnsListMonitor.h"
#include <string>
#include <commctrl.h> // For Tab Ctrl we have to include common controls

#define WM_SYSTRAYMSG  (WM_USER + 1)
NOTIFYICONDATA TrayIconData={0};
HWND m_hWndTray=0; // HWND of the messages window for the tray icon
bool m_bTrayIcon=false; // Is the tray icon created successfully? (So we have to dispose it)
HWND m_hWndSettings=0; // HWND of the settings window
HWND m_hWndSettingsPage1=0; // HWND of page 1 for the tab in the main window
HWND m_hWndSettingsPage2=0; // HWND of page 2 for the tab in the main window
bool m_bShowOnStart=true; // Do we need show the settings dialog?
bool m_bListenOnStart=false; // Do we need to start listening?
bool m_bTemporaryPort=false; // Are we using a temporary port specified in args?

CSQLiteServer m_Server;
CINIAuth m_INIAuth;
CConnsListMonitor m_ConnsMonitor;

HINSTANCE m_hInstance=0;

std::basic_string<TCHAR> m_strINIFile;

//////// Service members
SERVICE_STATUS m_ServiceStatus; 
SERVICE_STATUS_HANDLE m_ServiceStatusHandle;

void WINAPI ServiceCtrlHandler(DWORD Opcode);
bool InstallService();
bool UninstallService();
void WINAPI ServiceMain(DWORD argc, LPTSTR *argv);
///////////////////////

void InitTrayIcon();
ATOM RegisterTrayClass();
LRESULT CALLBACK TrayWndProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DialogProc(HWND, UINT, WPARAM, LPARAM);
std::basic_string<TCHAR> GetExeFilePath();
std::basic_string<TCHAR> FormatExeFilePath(LPCTSTR strFileName);
void RefreshUsersList();
void OnBnClickedAddUser();
void OnBnClickedDeleteUser();
void OnLbnSelchangeListUsers();
void OnLbnSelchangeListConns();

int APIENTRY _tWinMain(HINSTANCE hInstance,
					   HINSTANCE hPrevInstance,
					   LPTSTR    lpCmdLine,
					   int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	m_hInstance = hInstance; // Store instance handle in our global variable

	int iArgs=0;
	LPWSTR * pArgs=CommandLineToArgvW(lpCmdLine, &iArgs);

	bool bClose=false;
	if (pArgs)
	{
		bool bInstSvc=false;
		bool bRemSvc=false;

		for (int i=0; i<iArgs; i++)
		{
			if (!_wcsicmp(pArgs[i], L"/instsvc")) bInstSvc=true;
			else if (!_wcsicmp(pArgs[i], L"/remsvc")) bRemSvc=true;
			else if (!_wcsicmp(pArgs[i], L"/minimize")) m_bShowOnStart=false;
			else if (!_wcsicmp(pArgs[i], L"/start")) m_bListenOnStart=true;
			else if (!_wcsnicmp(pArgs[i], L"/port:", 6)) 
			{
				m_Server.SetServerPort((unsigned short)_ttoi(&pArgs[i][6]));
				m_bTemporaryPort=true;
			}
			else if (!_wcsicmp(pArgs[i], L"/?") || !_wcsicmp(pArgs[i], L"/help")) 
			{
				MessageBox(GetDesktopWindow(), 
					_T("Arguments:\n")
					_T("/instsvc - Install as a service\n")
					_T("/remsvc - Uninstall service\n")
					_T("/minimize - minimize to tray on startup\n")
					_T("/start - Start listening on startup\n")
					_T("/port:[port_num] - Set server listen port to [port_num]\n")
					_T("/? or /help - this message")
					, _T("SQLite Server Command Line Arguments"), 
					MB_OK | MB_ICONINFORMATION);
				bClose=true;
			}
		}

		if (bInstSvc)
		{
			if (InstallService())
			{
				MessageBox(GetDesktopWindow(), 
					_T("Service installed successfully"), 
					_T("SQLite Server Service"), 
					MB_OK | MB_ICONINFORMATION);
			} else {
				MessageBox(GetDesktopWindow(), 
					_T("An error occurred while installing as a service!"), 
					_T("SQLite Server Service"), 
					MB_OK | MB_ICONINFORMATION);
			}
			bClose=true;
		} else if (bRemSvc)
		{
			if (UninstallService())
			{
				MessageBox(GetDesktopWindow(), 
					_T("Service uninstalled successfully"), 
					_T("SQLite Server Service"), 
					MB_OK | MB_ICONINFORMATION);
			} else {
				MessageBox(GetDesktopWindow(), 
					_T("An error occurred while uninstalling the service!"), 
					_T("SQLite Server Service"), 
					MB_OK | MB_ICONINFORMATION);
			}
			bClose=true;
		}
	}
	if (pArgs) LocalFree(pArgs);

	m_strINIFile=FormatExeFilePath(_T("Settings.ini"));

	if (!bClose) 
	{
		SERVICE_TABLE_ENTRY DispatchTable[]={{_T("SQLite_Server"),ServiceMain},{NULL,NULL}};
		if (!StartServiceCtrlDispatcher(DispatchTable))
			ServiceMain(0, 0);
	}

	return 0;
}

void InitTrayIcon()
{
	m_hWndTray=CreateWindow(
		(LPCTSTR)RegisterTrayClass(), 
		_T(""), 
		WS_POPUP,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT, 
		CW_USEDEFAULT,
		NULL,
		0, 
		m_hInstance, 
		0
		);

	::memset(&TrayIconData, 0, sizeof(NOTIFYICONDATA));
	TrayIconData.hIcon            = LoadIcon(m_hInstance, MAKEINTRESOURCE(IDI_SMALLICON));
	TrayIconData.hWnd             = m_hWndTray;
	TrayIconData.uCallbackMessage = WM_SYSTRAYMSG;
	TrayIconData.uID              = 0;
	TrayIconData.cbSize           = sizeof(NOTIFYICONDATA);
	TrayIconData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	_tcscpy_s(TrayIconData.szTip, 64, _T("SQLite Server, by Daniel Cohen Gindi.\ndanielgindi@gmail.com"));

	::Shell_NotifyIcon(NIM_ADD, &TrayIconData);

	SetTimer(m_hWndTray, 0, 60000, 0);

	m_bTrayIcon=true;
}

ATOM RegisterTrayClass()
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= 0;
	wcex.lpfnWndProc	= TrayWndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= m_hInstance;
	wcex.hIcon			= 0;
	wcex.hCursor		= 0;
	wcex.hbrBackground	= 0;
	wcex.lpszMenuName	= 0;
	wcex.lpszClassName	= _T("SQLITE_SERVER_TRAY_WND");
	wcex.hIconSm		= 0;

	return RegisterClassEx(&wcex);
}

LRESULT CALLBACK TrayWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_SYSTRAYMSG:
		if (lParam==WM_RBUTTONDOWN)
		{
			POINT pt;
			::GetCursorPos(&pt);

			HMENU hMenu=LoadMenu(m_hInstance, MAKEINTRESOURCE(IDR_CONTEXT));
			HMENU hSubMenu=GetSubMenu(hMenu, 0);
 			if (m_Server.IsListening())
 			{
				EnableMenuItem(hSubMenu, ID_STARTLISTENING, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
 			} else 
 			{
				EnableMenuItem(hSubMenu, ID_STOPLISTENING, MF_BYCOMMAND | MF_DISABLED | MF_GRAYED);
 			}
			SetForegroundWindow(m_hWndTray);
			TrackPopupMenu(hSubMenu, TPM_RIGHTBUTTON, pt.x, pt.y, 0, m_hWndTray, 0);
			DestroyMenu(hMenu);
		} else if (lParam==WM_LBUTTONDBLCLK)
		{
			ShowWindow(m_hWndSettings, SW_SHOWNORMAL);
			SetForegroundWindow(m_hWndSettings);
		}
		break;
	case WM_COMMAND:
		{
			switch (wParam)
			{
			case ID_EXIT:
				if (MessageBox(GetDesktopWindow(), _T("Are you sure you want to exit SQLite Server?"), _T("SQLite Server"), MB_YESNO | MB_ICONQUESTION)==IDYES)
					PostQuitMessage(0);
				break;
			case ID_SHOW:
				ShowWindow(m_hWndSettings, SW_SHOWNORMAL);
				SetForegroundWindow(m_hWndSettings);
				break;
			case ID_STARTLISTENING:
				m_Server.Start();
				break;
			case ID_STOPLISTENING:
				m_Server.Stop();
				break;
			case ID_KILLCONNECTIONS:
				if (MessageBox(GetDesktopWindow(), _T("Are you sure you want to disconnect all existing connections?"), _T("SQLite Server"), MB_YESNO | MB_ICONQUESTION)==IDYES)
					m_Server.KillConnections();
				break;
			}
		}
		break;
	case WM_TIMER:
		// Refresh tray icon.
		// On a server the service might start when no user is logged on...
		if (::Shell_NotifyIcon(NIM_ADD, &TrayIconData))
			m_bTrayIcon=true;
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

BOOL CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_SHOWWINDOW:
		if (hDlg==m_hWndSettings)
		{
			if (m_Server.IsListening())
			{
				EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_START), FALSE);
				EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_STOP), TRUE);
			} else {
				EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_START), TRUE);
				EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_STOP), FALSE);
			}
		}

		break;

	case WM_INITDIALOG:
		{
			if (m_hWndSettings==0) // m_hWndSettings not created yet, means its it!
			{
				// Set m_hWndSettings so we do not catch WM_INITDIALOG again 
				//   for the same dialog.
				m_hWndSettings=hDlg; 

				// Create the pages
				m_hWndSettingsPage1=CreateDialog(m_hInstance, MAKEINTRESOURCE(IDD_SQLITE_SERVER_PAGE1), m_hWndSettings, DialogProc);
				m_hWndSettingsPage2=CreateDialog(m_hInstance, MAKEINTRESOURCE(IDD_SQLITE_SERVER_PAGE2), m_hWndSettings, DialogProc);

				::SendMessage(m_hWndSettings, WM_SETICON, TRUE, (LPARAM)LoadIcon(m_hInstance, MAKEINTRESOURCE(IDR_MAINFRAME)));
				SetDlgItemInt(m_hWndSettingsPage1, IDC_PORT, m_Server.GetServerPort(), FALSE);
				RefreshUsersList();

				// Initialize the TabCtrl
				TCITEM item;
				item.mask=TCIF_TEXT;
				item.pszText = (LPTSTR) _T("Main");
				::SendMessage(GetDlgItem(m_hWndSettings, IDC_TAB), TCM_INSERTITEM, 0, (LPARAM)&item);
				item.pszText = (LPTSTR) _T("Connections");
				::SendMessage(GetDlgItem(m_hWndSettings, IDC_TAB), TCM_INSERTITEM, 1, (LPARAM)&item);


				// Position the pages
				ShowWindow(m_hWndSettingsPage2, SW_HIDE);
				SetWindowPos(m_hWndSettingsPage1, 0, 12, 30, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
				SetWindowPos(m_hWndSettingsPage2, 0, 12, 30, 0, 0, SWP_NOSIZE);
			}
			return TRUE;
		}
		break;

	case WM_SIZE:
		if (wParam==SIZE_MINIMIZED) ShowWindow(m_hWndSettings, SW_HIDE);
		break;
	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case IDC_EXIT:
				if (MessageBox(m_hWndSettings, _T("Are you sure you want to exit SQLite Server?"), _T("SQLite Server"), MB_YESNO | MB_ICONQUESTION)==IDYES)
					PostQuitMessage(0);
				break;

			case IDC_MINIMIZE:
			case IDCANCEL:
				ShowWindow(m_hWndSettings, SW_HIDE);
				break;

			case IDC_START:
				m_Server.SetServerPort(GetDlgItemInt(m_hWndSettingsPage1, IDC_PORT, 0, FALSE));
				if (m_Server.Start())
				{
					EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_START), FALSE);
					EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_STOP), TRUE);
				}
				break;

			case IDC_STOP:
				m_Server.Stop();
				EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_START), TRUE);
				EnableWindow(GetDlgItem(m_hWndSettingsPage1, IDC_STOP), FALSE);
				break;

			case IDC_KILLALL:
				if (MessageBox(m_hWndSettings, _T("Are you sure you want to disconnect all existing connections?"), _T("SQLite Server"), MB_YESNO | MB_ICONQUESTION)==IDYES)
					m_Server.KillConnections();

				break;

			case IDC_KILL:
				{
					HWND hLst=GetDlgItem(m_hWndSettingsPage2, IDC_LIST_CONNS);
					int iSel=(int)::SendMessage(hLst, LB_GETCURSEL, 0, 0);
					if (iSel!=LB_ERR)
					{
						SOCKET sock=(SOCKET)::SendMessage(hLst, LB_GETITEMDATA, iSel, 0);
						socket_close(sock);
					}
				}

				break;

			case IDC_ADD_USER:
				OnBnClickedAddUser();
				break;

			case IDC_DELETE_USER:
				OnBnClickedDeleteUser();
				break;

			case IDC_LIST_USERS:
				if (HIWORD(wParam)==LBN_SELCHANGE) OnLbnSelchangeListUsers();
				break;

			case IDC_LIST_CONNS:
				if (HIWORD(wParam)==LBN_SELCHANGE) OnLbnSelchangeListConns();
				break;
			}
		}
		break;
	case WM_NOTIFY:
		{
			NMHDR * lpNMHDR = (NMHDR*) lParam;

			switch(lpNMHDR->idFrom)
			{
			case IDC_TAB:
				if (lpNMHDR->code==TCN_SELCHANGE)
				{
					int iSel=(int)::SendMessage(GetDlgItem(m_hWndSettings, IDC_TAB), TCM_GETCURSEL, 0, 0L);
					if (iSel==1)
					{
						ShowWindow(m_hWndSettingsPage1, SW_HIDE);
						ShowWindow(m_hWndSettingsPage2, SW_SHOWNORMAL);
					} else {
						ShowWindow(m_hWndSettingsPage2, SW_HIDE);
						ShowWindow(m_hWndSettingsPage1, SW_SHOWNORMAL);
					}
				}
				break;
			}
			break;
		}
 	case WM_KEYDOWN:
 		if (wParam==VK_ESCAPE) 
 		{
 			ShowWindow(m_hWndSettings, SW_HIDE);
 		}
 		break;
	}

	return FALSE;
}

std::basic_string<TCHAR> GetExeFilePath()
{
 	std::basic_string<TCHAR> strBuffer;
 	int iBufferSize=MAX_PATH+1;
	strBuffer.resize(iBufferSize);
 	GetModuleFileName(NULL, (LPTSTR)strBuffer.data(), iBufferSize);

 	while (GetLastError()==ERROR_INSUFFICIENT_BUFFER){
 		iBufferSize+=MAX_PATH;
		strBuffer.resize(iBufferSize);
 		GetModuleFileName(NULL, (LPTSTR)strBuffer.data(), iBufferSize);
 	}

 	return strBuffer;
}

std::basic_string<TCHAR> FormatExeFilePath(LPCTSTR strFileName)
{
	std::basic_string<TCHAR> strExe=GetExeFilePath();

	size_t iChar=strExe.rfind(_T('\\'));
	if (iChar==strExe.npos) iChar=strExe.rfind(_T('/'));
	if (iChar!=strExe.npos) strExe.resize(iChar);
	TCHAR cSeparator=_T('\\');
	if (strExe.rfind(_T('/'))!=strExe.npos) cSeparator=_T('/');
	strExe.append(1, cSeparator);
	strExe.append(strFileName);
	return strExe;
}

void RefreshUsersList()
{
	std::list<SQLITE_AUTH_USER> * pList=m_INIAuth.GetListPtr();

	HWND hListWnd=GetDlgItem(m_hWndSettingsPage1, IDC_LIST_USERS);
	::SendMessage(hListWnd, LB_RESETCONTENT, 0, 0);

	int iTabs[] = {60, 60};
	::SendMessage(hListWnd, LB_SETTABSTOPS, sizeof(iTabs)/sizeof(int), (LPARAM)iTabs);

	std::basic_string<TCHAR> str;

	for (std::list<SQLITE_AUTH_USER>::iterator pos=pList->begin();
		pos!=pList->end(); pos++)
	{
		str=(*pos).user;
		str.append(1, _T('\t'));
		if (((*pos).rights&sqliteRightWrite) && ((*pos).rights&sqliteRightCreateDB))
			str.append(_T("Full Permissions"));
		else if (((*pos).rights&sqliteRightRead) && ((*pos).rights&sqliteRightCreateDB))
			str.append(_T("Create DB / Read"));
		else if (((*pos).rights&sqliteRightCreateDB))
			str.append(_T("Create DB"));
		else if (((*pos).rights&sqliteRightWrite))
			str.append(_T("Read/Write Permissions"));
		else if (((*pos).rights&sqliteRightRead))
			str.append(_T("Read Permissions"));
		else str.append(_T("No Permissions!"));

		::SendMessage(hListWnd, LB_ADDSTRING, 0, (LPARAM)str.data());
	}
}


void OnBnClickedAddUser()
{
	TCHAR strUser[64];
	TCHAR strPass[64];
	GetDlgItemText(m_hWndSettingsPage1, IDC_USER, strUser, 64);
	GetDlgItemText(m_hWndSettingsPage1, IDC_PASS, strPass, 64);
	SQLiteAccessRights rights=sqliteNoRights;
	if (IsDlgButtonChecked(m_hWndSettingsPage1, IDC_PERM_READ)==BST_CHECKED) rights=(SQLiteAccessRights)(rights|sqliteRightRead);
	if (IsDlgButtonChecked(m_hWndSettingsPage1, IDC_PERM_WRITE)==BST_CHECKED) rights=(SQLiteAccessRights)(rights|sqliteRightWrite);
	if (IsDlgButtonChecked(m_hWndSettingsPage1, IDC_PERM_CREATEDB)==BST_CHECKED) rights=(SQLiteAccessRights)(rights|sqliteRightCreateDB);

	m_INIAuth.SetUser(strUser, strPass, rights);
	RefreshUsersList();
}

void OnBnClickedDeleteUser()
{
	HWND hListWnd=GetDlgItem(m_hWndSettingsPage1, IDC_LIST_USERS);
	int iSel=(int)::SendMessage(hListWnd, LB_GETCURSEL, 0, 0);
	if (iSel==LB_ERR) return;

	int iLen=(int)::SendMessage(hListWnd, LB_GETTEXTLEN, iSel, 0);
	TCHAR * pBuf=new TCHAR[iLen+1];

	::SendMessage(hListWnd, LB_GETTEXT, iSel, (LPARAM)pBuf);

	int iT;
	for (iT=0; iT<iLen; iT++)
	{
		if (pBuf[iT]==_T('\t')) break;
	}
	pBuf[iT]=0;
	m_INIAuth.RemoveUser(pBuf);
	delete [] pBuf;

	RefreshUsersList();
}

void OnLbnSelchangeListUsers()
{
	HWND hListWnd=GetDlgItem(m_hWndSettingsPage1, IDC_LIST_USERS);
	int iSel=(int)::SendMessage(hListWnd, LB_GETCURSEL, 0, 0);
	if (iSel==LB_ERR) return;

	int iLen=(int)::SendMessage(hListWnd, LB_GETTEXTLEN, iSel, 0);
	TCHAR * pBuf=new TCHAR[iLen+1];
	::SendMessage(hListWnd, LB_GETTEXT, iSel, (LPARAM)pBuf);
	int iT;
	for (iT=0; iT<iLen; iT++)
	{
		if (pBuf[iT]==_T('\t')) break;
	}
	pBuf[iT]=0;

	SQLITE_AUTH_USER * pUser=m_INIAuth.GetUser(pBuf);
	if (pUser)
	{
		SetDlgItemText(m_hWndSettingsPage1, IDC_USER, pUser->user.data());
		SetDlgItemText(m_hWndSettingsPage1, IDC_PASS, _T(""));

		CheckDlgButton(m_hWndSettingsPage1, IDC_PERM_READ, (pUser->rights&sqliteRightRead)?BST_CHECKED:BST_UNCHECKED);
		CheckDlgButton(m_hWndSettingsPage1, IDC_PERM_WRITE, (pUser->rights&sqliteRightWrite)?BST_CHECKED:BST_UNCHECKED);
		CheckDlgButton(m_hWndSettingsPage1, IDC_PERM_CREATEDB, (pUser->rights&sqliteRightCreateDB)?BST_CHECKED:BST_UNCHECKED);
	}
	delete [] pBuf;
}

void OnLbnSelchangeListConns()
{
	HWND hListWnd=GetDlgItem(m_hWndSettingsPage2, IDC_LIST_CONNS);
	int iSel=(int)::SendMessage(hListWnd, LB_GETCURSEL, 0, 0);
	EnableWindow(GetDlgItem(m_hWndSettingsPage2, IDC_KILL), iSel!=LB_ERR);
}

bool InstallService()
{
	std::basic_string<TCHAR> strPath=GetExeFilePath();

	SC_HANDLE schSCManager,schService;
	schSCManager = OpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);

	if (schSCManager == NULL) return false;

	schService = CreateService(schSCManager, _T("SQLite_Server"), 
		_T("SQLite Server"), // service name to display
		SERVICE_ALL_ACCESS, // desired access 
		SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS, // service type 
		SERVICE_AUTO_START, // start type 
		SERVICE_ERROR_NORMAL, // error control type 
		strPath.data(), // service's binary 
		NULL, // no load ordering group 
		NULL, // no tag identifier 
		NULL, // no dependencies
		NULL, // LocalSystem account
		NULL); // no password

	if (schService == NULL)
		return false; 

	CloseServiceHandle(schService);
	return true;
}

bool UninstallService()
{
	SC_HANDLE schSCManager;
	SC_HANDLE hService;
	schSCManager = OpenSCManager(NULL,NULL,SC_MANAGER_ALL_ACCESS);

	if (schSCManager == NULL)
		return false;
	hService=OpenService(schSCManager,_T("SQLite_Server"),SERVICE_ALL_ACCESS);
	if (hService == NULL)
		return false;
	if(DeleteService(hService)==0)
		return false;
	if(CloseServiceHandle(hService)==0)
		return false;

	return true;
}

void WINAPI ServiceCtrlHandler(DWORD Opcode)
{
	switch(Opcode)
	{
	case SERVICE_CONTROL_PAUSE: 
		m_ServiceStatus.dwCurrentState = SERVICE_PAUSED;
		m_Server.Stop();
		break;
	case SERVICE_CONTROL_CONTINUE:
		m_ServiceStatus.dwCurrentState = SERVICE_RUNNING;
		m_Server.Start();
		break;
	case SERVICE_CONTROL_SHUTDOWN:
	case SERVICE_CONTROL_STOP:
		m_ServiceStatus.dwWin32ExitCode = 0;
		m_ServiceStatus.dwCurrentState = SERVICE_STOPPED;
		m_ServiceStatus.dwCheckPoint = 0;
		m_ServiceStatus.dwWaitHint = 0;

		PostQuitMessage(0);
		break;
	case SERVICE_CONTROL_INTERROGATE:
		break; 
	}
	SetServiceStatus (m_ServiceStatusHandle,&m_ServiceStatus);
	return;
}

void WINAPI ServiceMain(DWORD argc, LPTSTR *argv)
{
	memset(&m_ServiceStatus, 0, sizeof(m_ServiceStatus));
	m_ServiceStatus.dwServiceType = SERVICE_WIN32;
	m_ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
	m_ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	m_ServiceStatus.dwWin32ExitCode = 0;
	m_ServiceStatus.dwServiceSpecificExitCode = 0;
	m_ServiceStatus.dwCheckPoint = 0;
	m_ServiceStatus.dwWaitHint = 0;

	m_ServiceStatusHandle = RegisterServiceCtrlHandler(_T("SQLite_Server"), ServiceCtrlHandler); 

	if (m_ServiceStatusHandle!=0) 
	{
		m_bShowOnStart=false;
		m_bListenOnStart=true;
	}

	m_Server.SetServerPort(GetPrivateProfileInt(_T("SQLiteServer"), _T("ServerPort"), m_Server.GetServerPort(), m_strINIFile.data()));

	CSQLiteServer::InitSockets();

	InitTrayIcon();

	m_hWndSettings=CreateDialog(m_hInstance, MAKEINTRESOURCE(IDD_SQLITE_SERVER_DIALOG), 0, DialogProc);

	m_ConnsMonitor.m_hLstCtrl=GetDlgItem(m_hWndSettingsPage2, IDC_LIST_CONNS);

	m_Server.m_pAuthLayer=&m_INIAuth;
	m_Server.m_pConnsLayer=&m_ConnsMonitor;
	m_INIAuth.SetINIFileName(m_strINIFile.data());
	m_INIAuth.ReadAll();

	if (m_bListenOnStart) m_Server.Start();

	m_ServiceStatus.dwCurrentState = SERVICE_RUNNING;
	m_ServiceStatus.dwCheckPoint = 0;
	m_ServiceStatus.dwWaitHint = 0;
	SetServiceStatus (m_ServiceStatusHandle, &m_ServiceStatus);

	if (m_bShowOnStart) ShowWindow(m_hWndSettings, SW_SHOWNORMAL);

	MSG msg;

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (msg.message==WM_KEYDOWN)
		{
			if (GetActiveWindow()==m_hWndSettings)
			{
				DialogProc(m_hWndSettings, msg.message, msg.wParam, msg.lParam);
			}
		}
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	if (!m_bTemporaryPort)
	{
		TCHAR buf[16];
		_itot_s(GetDlgItemInt(m_hWndSettingsPage1, IDC_PORT, 0, FALSE), buf, 16, 10);
		WritePrivateProfileString(_T("SQLiteServer"), _T("ServerPort"), buf, m_strINIFile.data());
	}

	DestroyWindow(m_hWndSettingsPage1);
	DestroyWindow(m_hWndSettingsPage2);
	DestroyWindow(m_hWndSettings);

	if (m_bTrayIcon)
	{
		DestroyWindow(m_hWndTray);
		::Shell_NotifyIcon(NIM_DELETE, &TrayIconData);
	}

	m_INIAuth.SaveAll();
	m_Server.Stop();
	m_Server.KillConnections();
	CSQLiteServer::UninitSockets();

	m_ServiceStatus.dwWin32ExitCode = 0;
	m_ServiceStatus.dwCurrentState = SERVICE_STOPPED;
	m_ServiceStatus.dwCheckPoint = 0;
	m_ServiceStatus.dwWaitHint = 0;
	SetServiceStatus (m_ServiceStatusHandle,&m_ServiceStatus);

	return;
}
