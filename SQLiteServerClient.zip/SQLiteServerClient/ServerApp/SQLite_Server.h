// SQLite_Server.h : main header file
//

#pragma once

#include "resource.h"		// main symbols
