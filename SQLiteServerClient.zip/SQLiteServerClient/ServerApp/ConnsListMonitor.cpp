/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "ConnsListMonitor.h"

CConnsListMonitor::CConnsListMonitor()
{
	m_hLstCtrl=0;
}

CConnsListMonitor::~CConnsListMonitor()
{
}

void CConnsListMonitor::NewConnection(SOCKET sock)
{
	sockaddr_in addr;
	int iLen=sizeof(sockaddr_in);
	getpeername(sock, (sockaddr*)&addr, &iLen);

	TCHAR IP[16]; //000.000.000.000 == 15 chars + null char
	_sntprintf_s(IP,16,_T("%d.%d.%d.%d"),
		(BYTE)addr.sin_addr.S_un.S_un_b.s_b1,
		(BYTE)addr.sin_addr.S_un.S_un_b.s_b2,
		(BYTE)addr.sin_addr.S_un.S_un_b.s_b3,
		(BYTE)addr.sin_addr.S_un.S_un_b.s_b4);

	int iIndex=(int)::SendMessage(m_hLstCtrl, LB_ADDSTRING, 0, (LPARAM)&IP[0]);
	::SendMessage(m_hLstCtrl, LB_SETITEMDATA, iIndex, sock);
}

void CConnsListMonitor::ConnectionDropped(SOCKET sock)
{
	int iCount=(int)::SendMessage(m_hLstCtrl, LB_GETCOUNT, 0, 0);

	for (int i=0; i<iCount; i++)
	{
		if ((SOCKET)::SendMessage(m_hLstCtrl, LB_GETITEMDATA, i, 0)==sock)
		{
			::SendMessage(m_hLstCtrl, LB_DELETESTRING, i, 0);
		}
	}
}

