/************************************************************************
author:			Daniel C. Gindi (danielgindi (at) gmail (dot) com)

These classes are implementing a Client/Server architecture for
SQLite3 Library. (to download SQLite goto http://www.sqlite.org)

Some of the code (threads sockets etc...) is taken partly from Alex K's project,
you can find his code at http://www.it77.de/sqlite/sqlite.htm.
The code for turning SQLite's results into TCHAR and into table classes is taken
from my SQLite3 wrapper classes, 
to be found at http://www.codeproject.com/KB/cpp/SQLite3_Wrapper.aspx

Legal notes: You are free you use these classes for whatever use 
you have in mind, even commercial,
On one condition, don't ever claim you wrote it.
And if you wanna give me credits, I would like that... :-)

Contact notes: I can be contacted at (danielgindi (at) gmail (dot) com)
If you just wanna say thank you, or better, if you
think there's room for improvement for these
classes...
*************************************************************************/

#include "stdafx.h"
#include "INIAuth.h"
#include "../sha512/sha512_helper.h"

CINIAuth::CINIAuth()
{
	m_strINIFileName=0;
}

CINIAuth::~CINIAuth()
{
	if (m_strINIFileName) delete [] m_strINIFileName;
}

SQLiteAccessRights CINIAuth::IsAuthorized(char * strUser, char * strPass)
{
	LPTSTR user;
	LPTSTR pass;

	ConvertUTF8ToString(strUser, user);
	ConvertUTF8ToString(strPass, pass);

	for (std::list<SQLITE_AUTH_USER>::iterator pos=m_lstUsers.begin();
		pos!=m_lstUsers.end(); pos++)
	{
		if (!_tcsicmp((*pos).user.c_str(),user) && !_tcscmp((*pos).pass.c_str(),pass)) {
			delete [] user;
			delete [] pass;
			return (*pos).rights;
		}
	}
	delete [] user;
	delete [] pass;
	return sqliteNoRights;
}

void CINIAuth::SetINIFileName(LPCTSTR strFileName)
{
	if (m_strINIFileName) delete [] m_strINIFileName;
	if (strFileName)
	{
		int iLen=(int)_tcslen(strFileName);
		m_strINIFileName = new TCHAR[iLen+1];
		_tcsncpy_s(m_strINIFileName, iLen+1, strFileName, iLen);
	} else m_strINIFileName=0;
}

void CINIAuth::ReadAll()
{
	UINT iCount=GetPrivateProfileInt(_T("SQLiteServer"), _T("NumUsers"), 0, m_strINIFileName);
	LPTSTR lpFormat = new TCHAR[32];
	LPTSTR lpOutUser = new TCHAR[32];
	LPTSTR lpOutPass = new TCHAR[129];
	int iRights;
	for (UINT i=0; i<iCount; i++)
	{
		_stprintf_s(lpFormat, 32, _T("SQLiteServer_User%d"), i);
		GetPrivateProfileString(lpFormat, _T("UserName"), _T(""), lpOutUser, 32, m_strINIFileName);
		GetPrivateProfileString(lpFormat, _T("PassWord"), _T(""), lpOutPass, 129, m_strINIFileName);
		iRights=GetPrivateProfileInt(lpFormat, _T("Rights"), 0, m_strINIFileName);
		SetUser(lpOutUser, lpOutPass, (SQLiteAccessRights)iRights, false);
	}
	delete [] lpFormat;
	delete [] lpOutUser;
	delete [] lpOutPass;
}

void CINIAuth::SaveAll()
{
	LPTSTR lpFormat = new TCHAR[32];
	LPTSTR lpFormatInt = new TCHAR[16];
	_itot_s((int)m_lstUsers.size(), lpFormatInt, 16, 10);
	WritePrivateProfileString(_T("SQLiteServer"), _T("NumUsers"), lpFormatInt, m_strINIFileName);

	UINT i=0;
	for (std::list<SQLITE_AUTH_USER>::iterator pos=m_lstUsers.begin();
		pos!=m_lstUsers.end(); pos++)
	{
		_stprintf_s(lpFormat, 32, _T("SQLiteServer_User%d"), i);
		WritePrivateProfileString(lpFormat, _T("UserName"), (*pos).user.c_str(), m_strINIFileName);
		WritePrivateProfileString(lpFormat, _T("PassWord"), (*pos).pass.c_str(), m_strINIFileName);
		_itot_s((*pos).rights, lpFormatInt, 16, 10);
		WritePrivateProfileString(lpFormat, _T("Rights"), lpFormatInt, m_strINIFileName);

		i++;
	}

	delete [] lpFormat;
	delete [] lpFormatInt;
}

void CINIAuth::SetUser(LPCTSTR user, LPCTSTR pass, SQLiteAccessRights rights, bool bEncrypt/*=true*/)
{
	if (user==0 || pass==0) return;
	if (_tcslen(user)==0 || _tcslen(pass)==0) return;
	RemoveUser(user);
	SQLITE_AUTH_USER authuser;
	authuser.user=user;
	authuser.rights=rights;

	if (bEncrypt)
	{
		TCHAR pBuf[SHA512_DIGEST_SIZE*2+1];
		HashStringToHex((TCHAR*)pass, pBuf);

		authuser.pass=&pBuf[0];
		m_lstUsers.push_back(authuser);
	} else {
		authuser.pass=pass;
		m_lstUsers.push_back(authuser);
	}
}

void CINIAuth::RemoveUser(LPCTSTR user)
{
	for (std::list<SQLITE_AUTH_USER>::iterator pos=m_lstUsers.begin();
		pos!=m_lstUsers.end(); pos++)
	{
		if (!_tcsicmp((*pos).user.c_str(), user)) {
			m_lstUsers.erase(pos);
			return;
		}
	}
}

SQLITE_AUTH_USER * CINIAuth::GetUser(LPCTSTR user)
{
	for (std::list<SQLITE_AUTH_USER>::iterator pos=m_lstUsers.begin();
		pos!=m_lstUsers.end(); pos++)
	{
		if (!_tcsicmp((*pos).user.c_str(), user)) {
			return &(*pos);
		}
	}
	return 0;
}

bool CINIAuth::IsUser(LPCTSTR user)
{
	for (std::list<SQLITE_AUTH_USER>::iterator pos=m_lstUsers.begin();
		pos!=m_lstUsers.end(); pos++)
	{
		if (!_tcsicmp((*pos).user.c_str(),user)) return true;
	}
	return false;
}

void CINIAuth::ConvertUTF8ToString( char * strInUTF8MB, LPTSTR & strOut )
{
	size_t len=strlen(strInUTF8MB)+1;
	strOut=new TCHAR[len];
	strOut[0]=0;

#ifdef UNICODE
	MultiByteToWideChar(CP_UTF8, 0, strInUTF8MB, (int)len, strOut, (int)len);
#else
	WCHAR * wChar=new WCHAR[len];
	wChar[0]=0;
	MultiByteToWideChar(CP_UTF8, 0, strInUTF8MB, (int)len, wChar, (int)len);
	WideCharToMultiByte(CP_ACP, 0, wChar, (int)len, strOut, (int)len, 0, 0);
	delete [] wChar;
#endif
}